#!/usr/bin/env bash
# Stages, checks and builds this mod against a pinned Horizon checkout, using
# the real horizon-mixins CLI: the same flow the launcher runs when it
# compiles an installed .hnmod.
#
#   HORIZON=/path/to/horizon HORIZON_MIXINS=/path/to/horizon-mixins tools/stage.sh
#   WITH_LIB=1 …   also stage Tristan's Lib beside it (the coexistence check:
#                  two differently named crates, tristanpbty_armor_hud_lib
#                  and tristanpbty_lib, in one build)
#
# By default the mod is staged ALONE — it is self-contained: the library it
# uses is vendored in its bundle. The Horizon clone must contain the pinned
# commit (nightly 2026-11-08, fdc87ae...); the mixins clone must be at
# d9c83d7 (0.6.0). Nothing in either checkout is modified: horizon-mixins
# stages into target/mixins/modded.
set -euo pipefail
cd "$(dirname "$0")/.."

HORIZON="${HORIZON:-../horizon}"
MIXINS="${HORIZON_MIXINS:-../horizon-mixins}"

python3 - <<'PY'
import json, subprocess, sys
from pathlib import Path
compat = json.loads(Path('compatibility.json').read_text())
for name, want in [('horizon', compat['horizon_revision'][:12]),
                   ('horizon-mixins', compat['horizon_mixins_revision'][:7])]:
    path = {'horizon': Path('../horizon'), 'horizon-mixins': Path('../horizon-mixins')}[name]
    if not path.is_dir():
        sys.exit(f"missing {name} checkout at {path}")
    got = subprocess.run(['git', '-C', str(path), 'rev-parse', 'HEAD'],
                         capture_output=True, text=True).stdout.strip()
    if not got.startswith(want):
        sys.exit(f"{name} is at {got[:12]}, the mod pins {want}: checkout the pinned revision first")
print('pins ok')
PY

# The mod's own tests first (they exercise the vendored library too: it is
# the very crate the workspace builds against).
cargo test --workspace --locked --offline

MIXINS_BIN="$(cargo build --locked --release --manifest-path "$MIXINS/Cargo.toml" --message-format=json 2>/dev/null | python3 -c 'import json,sys; print([m for m in map(json.loads, sys.stdin) if m["reason"]=="compiler-artifact" and m["target"]["name"]=="horizon-mixins"][0]["executable"])')"

# The mods folder the CLI takes holds this mod's bundle — alone, as it
# installs — plus, with WITH_LIB=1, the standalone library mod beside it.
rm -rf target/mixins/bundles
mkdir -p target/mixins/bundles
cp -r mixins/tristanpbty_armor_hud target/mixins/bundles/
STAGED="tristanpbty_armor_hud"
if [ "${WITH_LIB:-0}" = "1" ]; then
    LIB="$(cd ../TristanPbtyLib && pwd)"
    (cd "$LIB" && python3 tools/sync_bundle.py)
    cp -r "$LIB"/mixins/tristanpbty_lib target/mixins/bundles/
    STAGED="tristanpbty_lib + tristanpbty_armor_hud"
fi

"$MIXINS_BIN" plan --workspace "$HORIZON" --mods target/mixins/bundles --out target/mixins/plan.json
"$MIXINS_BIN" apply --workspace "$HORIZON" --mods target/mixins/bundles --out target/mixins/modded
"$MIXINS_BIN" check --workspace "$HORIZON" --mods target/mixins/bundles --out target/mixins/modded --trust-native-mods
echo "staged game ($STAGED) at target/mixins/modded"
