#!/usr/bin/env python3
"""Vendors Tristan's Lib into this mod's bundle as its own crate.

The mod must build and run **alone**: a `.hnmod` is self-contained, so the
library its module uses rides along inside the bundle, staged by the
`[[crate]]` of `horizon-mixin.toml`. Horizon Mixins refuses a package name
that another staged crate already uses (`E_CRATE`), so the vendored copy is
renamed `tristanpbty_armor_hud_lib`: with the standalone library mod
(`tristanpbty_lib`) installed beside this one, the two differently named
crates coexist in the same build without conflict.

The sources are copied **byte for byte** from the TristanPbtyLib checkout
beside this project — only the `Cargo.toml` is rewritten (the crate name, the
description, and no `[workspace]` table, which Horizon Mixins rejects in a
bundle crate). Run this after editing the library, then re-run the tests and
the packager. This is a development helper for the monorepo layout: the
committed copy in `mixins/tristanpbty_armor_hud/lib/` is what builds and
ships, so `tools/package.py` never calls this — a checkout of this repository
alone rebuilds the `.hnmod` without the library's sources.
"""
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT.parent / "TristanPbtyLib"
DEST = ROOT / "mixins" / "tristanpbty_armor_hud" / "lib"

VENDORED_NAME = "tristanpbty_armor_hud_lib"


def vendored_cargo() -> str:
    """The Lib's Cargo.toml, renamed for the vendored copy.

    Same version and grants; a name of its own so the crate never collides
    with the standalone library mod's (`E_CRATE` otherwise); no `[workspace]`
    table (Horizon Mixins rejects one in a bundle crate); still zero
    dependencies (a bundle crate may only use what the game already locks).
    """
    version = {}
    for line in (LIB / "Cargo.toml").read_text().splitlines():
        if line.startswith("version = "):
            version["version"] = line
            break
    return f"""[package]
name = "{VENDORED_NAME}"
{version["version"]}
edition = "2024"
rust-version = "1.95"
license = "MIT"
authors = ["TristanPbty"]
description = "Tristan's Lib vendored inside TristanPbty's Armor Hud as its own crate, so the mod builds alone; the standalone tristanpbty_lib mod can sit beside it without conflict"
publish = false

[lib]
name = "{VENDORED_NAME}"
path = "src/lib.rs"

# Deliberately no dependencies, like the library it is a copy of: a Horizon
# native bundle crate may only use registry crates already present in the
# game's Cargo.lock, and a zero-dependency library stays portable.
[dependencies]
"""


if not LIB.is_dir():
    raise SystemExit(f"missing the TristanPbtyLib checkout at {LIB}")
if DEST.exists():
    shutil.rmtree(DEST)
DEST.mkdir(parents=True)
shutil.copytree(LIB / "src", DEST / "src")
(DEST / "Cargo.toml").write_text(vendored_cargo())
print(f"vendored {LIB} -> {DEST} (crate {VENDORED_NAME})")
