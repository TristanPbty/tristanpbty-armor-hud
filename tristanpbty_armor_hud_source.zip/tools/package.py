#!/usr/bin/env python3
"""Packages the mod as a source-only `.hnmod`, the file Horizon's registry
and launcher take.

The archive holds `horizon-native.json` and every `.rs`/`.toml` of
`mixins/<id>/` — the injected runtime, the hook helpers, the manifest, the
vendored library crate (`lib/`, staged by the `[[crate]]` so the mod builds
alone) and the licence — with fixed dates and modes so the same sources
always give the same bytes and the same SHA-256. Horizon's
`horizon_mods::index::native` reads it without running anything; the
launcher compiles it on the pinned Horizon revision. The library copy is
committed in the bundle (regenerated only by the developer's
`tools/sync_bundle.py`), so this script needs nothing beside the checkout.

Adapted from the MIT-licensed packager of horizon-native-mod-template (itself
based on levzzz5154's Veinminer packager).
"""
import hashlib
import json
import tomllib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GAME = '26.3'
VENDORED_CRATE = 'tristanpbty_armor_hud_lib'


def package() -> None:
    compat = json.loads((ROOT / 'compatibility.json').read_text())
    manifests = sorted((ROOT / 'mixins').glob('*/horizon-mixin.toml'))
    if len(manifests) != 1:
        raise SystemExit('a .hnmod holds one bundle: keep one mixins/<id>/horizon-mixin.toml')
    bundle = manifests[0].parent
    mixin = tomllib.loads(manifests[0].read_text())
    mod = mixin['mod']
    if bundle.name != mod['id']:
        raise SystemExit(f"rename mixins/{bundle.name}/ to mixins/{mod['id']}/ (the registry finds it by id)")
    if not mod['id'].replace('_', '').isalnum() or not mod['id'].islower():
        raise SystemExit('the registry takes ids of lowercase letters, digits and _ only')
    if mixin.get('compatibility', {}).get('horizon_revision') != compat['horizon_revision']:
        raise SystemExit('horizon-mixin.toml and compatibility.json pin different Horizon revisions')
    # The runtime hardcodes the version (env! would read the host crate's
    # version once injected), so it must be checked against the manifest's.
    runtime = (bundle / 'runtime.rs').read_text()
    version_line = f'pub const MOD_VERSION: &str = "{mod["version"]}";'
    if version_line not in runtime:
        raise SystemExit(f"runtime.rs's MOD_VERSION must be {version_line!r} to match the manifest")
    # The vendored library crate must be exactly what Horizon Mixins accepts:
    # its own package name (never the standalone lib's, which E_CRATE would
    # reject if that mod were installed too), no [workspace] table (rejected
    # in a bundle crate) and no Cargo.lock of its own (rejected likewise).
    vendored = bundle / 'lib'
    vcargo = tomllib.loads((vendored / 'Cargo.toml').read_text())
    if vcargo['package']['name'] != VENDORED_CRATE:
        raise SystemExit(f"the vendored lib/Cargo.toml must name the crate {VENDORED_CRATE!r}")
    if 'workspace' in vcargo:
        raise SystemExit('the vendored lib/Cargo.toml must carry no [workspace] table')
    if not vcargo.get('dependencies', {}) == {}:
        raise SystemExit('the vendored lib must stay dependency-free (bundle-crate rule)')
    if any(p.name == 'Cargo.lock' for p in vendored.rglob('*')):
        raise SystemExit('the vendored lib must carry no Cargo.lock of its own')
    if any(p.is_file() and p.suffix not in ('.rs', '.toml') for p in vendored.rglob('*')):
        raise SystemExit('the vendored lib holds a non-source file: only .rs and .toml ship')
    manifest = dict(schema=1, id=mod['id'], version=mod['version'], game=GAME,
                    horizon=compat['horizon_revision'], mixins=compat['horizon_mixins_revision'])
    files = {'horizon-native.json': (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()}
    for path in sorted(bundle.rglob('*')):
        if path.is_file() and path.suffix in ('.rs', '.toml'):
            files[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    # The licence travels with the sources, as Horizon's own native mods do:
    # at the project root (a standalone checkout), or one level up (the
    # monorepo development layout).
    licence = next((p for p in (ROOT / 'LICENSES.md', ROOT.parent / 'LICENSES.md') if p.is_file()), None)
    if licence is not None:
        files.setdefault(f'mixins/{mod["id"]}/LICENSES.md', licence.read_bytes())
    out = ROOT / 'target' / f"{mod['id']}-{mod['version']}.hnmod"
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, content in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, content)
    print(json.dumps(dict(file=str(out), size=out.stat().st_size,
                          sha256=hashlib.sha256(out.read_bytes()).hexdigest()), indent=2))


if __name__ == '__main__':
    package()
