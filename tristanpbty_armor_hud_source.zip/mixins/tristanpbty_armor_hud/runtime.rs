// TristanPbty's Armor Hud runtime: the mod's whole logic, kept free of the
// game's types so it builds and tests standalone as well as injected.
//
// This file is compiled twice: as the standalone `tristanpbty_armor_hud`
// library (unit tests included) and as the `crate::game::tristanpbty_armor_hud`
// module horizon-mixins injects into Horizon's `game.rs`. It therefore uses
// no inner file attributes, no external modules and no `include!`, and every
// game-specific call stays in the small hook helpers beside it.
//
// The layout follows the reference armor HUD mods (uku3lig/armor-hud, itself
// a fork of BerdinskiyBear's) in geometry and configuration vocabulary,
// reimplemented natively: anchors beside the hotbar or in the screen edges,
// slot styles cut from the vanilla hotbar sprites, per-item durability text
// and a low-durability warning, with the off-hand and attack-indicator
// spacing rules of the original.

pub use tristanpbty_armor_hud_lib::config::ConfigRuntime;
// Test-only inside this file: the values the module's own tests write. The
// re-export is `cfg(test)` so the injected game build (which compiles the
// module without its tests) sees no unused import.
#[cfg(test)]
use tristanpbty_armor_hud_lib::config::value::ConfigValue;
pub use tristanpbty_armor_hud_lib::minecraft::{EquipmentSnapshot, SlotKind, StackInfo};
pub use tristanpbty_armor_hud_lib::utils::{Anchor, Orientation, Rect, Side};
pub use tristanpbty_armor_hud_lib::widgets::DrawCmd;

use std::path::PathBuf;
use std::sync::{Mutex, OnceLock};
use tristanpbty_armor_hud_lib::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};
use tristanpbty_armor_hud_lib::config::{Disk, FsDisk};
use tristanpbty_armor_hud_lib::widgets::button::Button;
use tristanpbty_armor_hud_lib::widgets::cycle_button::CycleButton;
use tristanpbty_armor_hud_lib::widgets::{InputEvent, Widget};

/// The mod's registry id: its folder, its log key and its settings key.
pub const MOD_ID: &str = "tristanpbty_armor_hud";
/// The name the mod manager shows (`Name 1.0`, as native mods are listed).
pub const MOD_NAME: &str = "TristanPbty's Armor Hud";
/// The mod's version. Hardcoded — not `env!(CARGO_PKG_VERSION)`, which would
/// read the *host* crate's version once this file is injected into Horizon.
pub const MOD_VERSION: &str = "1.1.0";
/// The one-line description the mod manager shows under the name.
pub const MOD_DESCRIPTION: &str = "A minimal armor HUD beside the hotbar, with durability and low-durability warnings. By TristanPbty.";
/// The menu key's name in the game's mod-key storage
/// (`key.tristanpbty_armor_hud.menu` in `horizon-mods.txt`).
pub const MENU_KEY_NAME: &str = "menu";
/// The label the mod manager's keybind row shows.
pub const MENU_KEY_LABEL: &str = "Open the configuration screen";
/// The menu key's default.
pub const DEFAULT_MENU_KEY: &str = "key.keyboard.h";
/// The mod's emblem, drawn on its configuration screen beside the name:
/// the vanilla turtle helmet item (`casque de tortue`).
pub const MOD_LOGO_ITEM: &str = "minecraft:turtle_helmet";
/// The sound played when a low-durability warning appears: vanilla's own
/// item-break event (what the game plays when a piece actually breaks),
/// the sound the reference mods ship a copy of. A native bundle cannot
/// add audio to the game's prepared resources, so the vanilla event is
/// the faithful choice.
pub const BREAK_SOUND: &str = "minecraft:entity.item.break";
/// How long the warning sound stays quiet after playing once, however the
/// warnings flicker (mending can swing a piece back over the threshold).
pub const WARNING_SOUND_COOLDOWN_MS: u64 = 1500;
/// The volume and pitch `LivingEntity.breakItem` plays the break sound at.
pub const BREAK_SOUND_VOLUME: f32 = 0.8;
pub const BREAK_SOUND_PITCH: f32 = 1.0;

pub mod ids {
    // Configuration keys, in schema order.
    pub const ENABLED: &str = "enabled";
    pub const ANCHOR: &str = "anchor";
    pub const SIDE: &str = "side";
    pub const OFFSET_X: &str = "offsetX";
    pub const OFFSET_Y: &str = "offsetY";
    pub const SCALE: &str = "scale";
    pub const STYLE: &str = "style";
    pub const ORIENTATION: &str = "orientation";
    pub const WIDGET_SHOWN: &str = "widgetShown";
    pub const OFFHAND_SLOT_BEHAVIOR: &str = "offhandSlotBehavior";
    pub const DURABILITY_DISPLAY: &str = "durabilityDisplay";
    pub const TEXT_COLOR: &str = "textColor";
    pub const OFFHAND_DURABILITY: &str = "offHandDurability";
    pub const MAINHAND_DURABILITY: &str = "mainHandDurability";
    pub const PUSH_BOSSBARS: &str = "pushBossbars";
    pub const PUSH_STATUS_EFFECT_ICONS: &str = "pushStatusEffectIcons";
    pub const PUSH_SUBTITLES: &str = "pushSubtitles";
    pub const REVERSED: &str = "reversed";
    pub const ICONS_SHOWN: &str = "iconsShown";
    pub const WARNING_SHOWN: &str = "warningShown";
    pub const MIN_DURABILITY_VALUE: &str = "minDurabilityValue";
    pub const MIN_DURABILITY_PERCENTAGE: &str = "minDurabilityPercentage";
    pub const WARNING_ICON_BOBBING_INTERVAL_MS: &str = "warningIconBobbingIntervalMs";
    pub const WARNING_SOUND: &str = "warningSound";
}

/// How an empty-or-not widget decides to draw.
#[derive(Clone, Copy, PartialEq)]
pub enum WidgetShown {
    Always,
    IfAnyPresent,
    NotEmpty,
}

/// The off-hand spacing rule when anchored beside the hotbar.
#[derive(Clone, Copy, PartialEq)]
pub enum OffhandSlotBehavior {
    AlwaysIgnore,
    Adhere,
    AlwaysLeaveSpace,
}

/// The slot background style.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Style {
    Hotbar,
    RoundedCorners,
    Rounded,
    None,
}

/// How durability is written next to an item.
#[derive(Clone, Copy, PartialEq)]
pub enum DurabilityDisplay {
    Bar,
    Number,
    Percentage,
}

/// The durability text's color. `Auto` keeps vanilla's damage scale (green
/// when pristine, red when nearly gone); the rest are the chat palette's
/// own colors, held whatever the damage.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum TextColor {
    Auto,
    White,
    Gray,
    Red,
    Orange,
    Yellow,
    Green,
    Aqua,
    Blue,
    Purple,
    Pink,
}

impl TextColor {
    /// The schema's variant names, in cycle order.
    pub const NAMES: &'static [&'static str] = &[
        "AUTO", "WHITE", "GRAY", "RED", "ORANGE", "YELLOW", "GREEN", "AQUA", "BLUE", "PURPLE",
        "PINK",
    ];

    pub fn from_name(name: &str) -> TextColor {
        match name {
            "WHITE" => TextColor::White,
            "GRAY" => TextColor::Gray,
            "RED" => TextColor::Red,
            "ORANGE" => TextColor::Orange,
            "YELLOW" => TextColor::Yellow,
            "GREEN" => TextColor::Green,
            "AQUA" => TextColor::Aqua,
            "BLUE" => TextColor::Blue,
            "PURPLE" => TextColor::Purple,
            "PINK" => TextColor::Pink,
            _ => TextColor::Auto,
        }
    }

    /// The color a text of durability `ratio` (1 pristine … 0 broken) wears.
    pub fn rgb(self, ratio: f32) -> u32 {
        match self {
            TextColor::Auto => tristanpbty_armor_hud_lib::utils::durability_color(ratio),
            TextColor::White => 0xFFFF_FFFF,
            TextColor::Gray => 0xFFAA_AAAA,
            TextColor::Red => 0xFFFF_5555,
            TextColor::Orange => 0xFFFF_AA00,
            TextColor::Yellow => 0xFFFF_FF55,
            TextColor::Green => 0xFF55_FF55,
            TextColor::Aqua => 0xFF55_FFFF,
            TextColor::Blue => 0xFF55_55FF,
            TextColor::Purple => 0xFFAA_00AA,
            TextColor::Pink => 0xFFFF_55FF,
        }
    }
}

/// The mod's whole configuration, read straight from the runtime. Cloned per
/// frame in one go so the layout works on plain values.
#[derive(Clone)]
pub struct Settings {
    pub enabled: bool,
    pub anchor: Anchor,
    pub side: Side,
    pub offset_x: i32,
    pub offset_y: i32,
    pub scale: f32,
    pub style: Style,
    pub orientation: Orientation,
    pub widget_shown: WidgetShown,
    pub offhand_slot_behavior: OffhandSlotBehavior,
    pub durability_display: DurabilityDisplay,
    pub text_color: TextColor,
    pub offhand_durability: bool,
    pub mainhand_durability: bool,
    pub push_bossbars: bool,
    pub push_status_effect_icons: bool,
    pub push_subtitles: bool,
    pub reversed: bool,
    pub icons_shown: bool,
    pub warning_shown: bool,
    pub min_durability_value: i64,
    pub min_durability_percentage: f64,
    pub warning_icon_bobbing_interval_ms: i64,
    pub warning_sound: bool,
}

// ---------------------------------------------------------------------------
// The configuration schema.
// ---------------------------------------------------------------------------

pub mod schema {
    use super::*;

    pub const ANCHORS: &[&str] = &["TOP_CENTER", "TOP", "CENTER", "BOTTOM", "HOTBAR"];
    pub const SIDES: &[&str] = &["LEFT", "RIGHT"];
    pub const ORIENTATIONS: &[&str] = &["HORIZONTAL", "VERTICAL"];
    pub const STYLES: &[&str] = &["HOTBAR", "ROUNDED_CORNERS", "ROUNDED", "NONE"];
    pub const WIDGET_SHOWN: &[&str] = &["ALWAYS", "IF_ANY_PRESENT", "NOT_EMPTY"];
    pub const OFFHAND_BEHAVIORS: &[&str] = &["ALWAYS_IGNORE", "ADHERE", "ALWAYS_LEAVE_SPACE"];
    pub const DURABILITY_DISPLAYS: &[&str] = &["BAR", "NUMBER", "PERCENTAGE"];
    pub const TEXT_COLORS: &[&str] = TextColor::NAMES;

    const GENERAL: &[ConfigEntry] = &[
        ConfigEntry::bool(
            ids::ENABLED,
            "Armor HUD",
            "Master switch for the whole widget",
            true,
        ),
        ConfigEntry::enumeration(
            ids::STYLE,
            "Slot style",
            "How the slot row is drawn",
            STYLES,
            "HOTBAR",
        ),
        ConfigEntry::enumeration(
            ids::ORIENTATION,
            "Orientation",
            "The direction the row grows",
            ORIENTATIONS,
            "HORIZONTAL",
        ),
        ConfigEntry::enumeration(
            ids::WIDGET_SHOWN,
            "Shown",
            "When the slots are drawn",
            WIDGET_SHOWN,
            "NOT_EMPTY",
        ),
        ConfigEntry::bool(
            ids::REVERSED,
            "Reversed",
            "Draw the armor from the boots up",
            false,
        ),
        ConfigEntry::bool(
            ids::ICONS_SHOWN,
            "Empty slot icons",
            "Vanilla's slot type icons in empty slots",
            true,
        ),
    ];
    const POSITION: &[ConfigEntry] = &[
        ConfigEntry::enumeration(
            ids::ANCHOR,
            "Anchor",
            "Where the widget attaches",
            ANCHORS,
            "HOTBAR",
        ),
        ConfigEntry::enumeration(ids::SIDE, "Side", "Which side of the anchor", SIDES, "LEFT"),
        ConfigEntry::int(
            ids::OFFSET_X,
            "X offset",
            "Away from the anchor, GUI pixels",
            0,
            -500,
            500,
        ),
        ConfigEntry::int(
            ids::OFFSET_Y,
            "Y offset",
            "Down from top anchors, up from bottom ones",
            0,
            -500,
            500,
        ),
        ConfigEntry::scale(
            ids::SCALE,
            "Scale",
            "Widget scale (a TristanPbty extension)",
            1.0,
            0.5,
            2.0,
        ),
        ConfigEntry::enumeration(
            ids::OFFHAND_SLOT_BEHAVIOR,
            "Off-hand spacing",
            "Space left for the off-hand slot and attack indicator beside the hotbar",
            OFFHAND_BEHAVIORS,
            "ADHERE",
        ),
    ];
    const DISPLAY: &[ConfigEntry] = &[
        ConfigEntry::enumeration(
            ids::DURABILITY_DISPLAY,
            "Durability",
            "How an item's durability is written",
            DURABILITY_DISPLAYS,
            "BAR",
        ),
        ConfigEntry::enumeration(
            ids::TEXT_COLOR,
            "Text color",
            "The durability text's color; Auto follows the damage",
            TEXT_COLORS,
            "AUTO",
        ),
        ConfigEntry::bool(
            ids::OFFHAND_DURABILITY,
            "Off-hand durability",
            "Durability under the off-hand slot",
            true,
        ),
        ConfigEntry::bool(
            ids::MAINHAND_DURABILITY,
            "Main-hand durability",
            "Durability under the selected hotbar slot",
            false,
        ),
    ];
    const WARNINGS: &[ConfigEntry] = &[
        ConfigEntry::bool(
            ids::WARNING_SHOWN,
            "Low durability warning",
            "A warning mark on nearly broken items",
            true,
        ),
        ConfigEntry::int(
            ids::MIN_DURABILITY_VALUE,
            "Minimum points",
            "Warn at or below this many points left",
            20,
            0,
            500,
        ),
        ConfigEntry::float(
            ids::MIN_DURABILITY_PERCENTAGE,
            "Minimum percentage",
            "Warn at or below this share of durability left; one click is 5%",
            0.1,
            0.0,
            1.0,
            0.05,
        ),
        ConfigEntry::int(
            ids::WARNING_ICON_BOBBING_INTERVAL_MS,
            "Warning bobbing (ms)",
            "One up-down cycle of the warning mark; 0 holds it still",
            2000,
            0,
            10000,
        ),
        ConfigEntry::bool(
            ids::WARNING_SOUND,
            "Warning sound",
            "Play the item-break sound when a warning appears",
            true,
        ),
    ];
    const COMPATIBILITY: &[ConfigEntry] = &[
        ConfigEntry::bool(
            ids::PUSH_BOSSBARS,
            "Push bossbars down",
            "Reserved: needs an upstream offset hook",
            true,
        ),
        ConfigEntry::bool(
            ids::PUSH_STATUS_EFFECT_ICONS,
            "Push effect icons",
            "Stack below the status effect rows at the top",
            true,
        ),
        ConfigEntry::bool(
            ids::PUSH_SUBTITLES,
            "Push subtitles up",
            "Reserved: needs an upstream offset hook",
            true,
        ),
    ];
    const TABS: &[ConfigTab] = &[
        ConfigTab {
            id: "general",
            label: "General",
            entries: GENERAL,
        },
        ConfigTab {
            id: "position",
            label: "Position",
            entries: POSITION,
        },
        ConfigTab {
            id: "display",
            label: "Display",
            entries: DISPLAY,
        },
        ConfigTab {
            id: "warnings",
            label: "Warnings",
            entries: WARNINGS,
        },
        ConfigTab {
            id: "compatibility",
            label: "Compat",
            entries: COMPATIBILITY,
        },
    ];
    pub static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: MOD_ID,
        version: 1,
        tabs: TABS,
    };
}

/// Reads the settings out of a runtime in one clone.
pub fn settings_of(runtime: &ConfigRuntime) -> Settings {
    let text = |key: &str| runtime.text(key).to_string();

    Settings {
        enabled: runtime.bool(ids::ENABLED),
        anchor: Anchor::from_name(&text(ids::ANCHOR)).unwrap_or(Anchor::Hotbar),
        side: Side::from_name(&text(ids::SIDE)).unwrap_or(Side::Left),
        offset_x: runtime.int(ids::OFFSET_X) as i32,
        offset_y: runtime.int(ids::OFFSET_Y) as i32,
        scale: runtime.scale(ids::SCALE).clamp(0.5, 2.0),
        style: match text(ids::STYLE).as_str() {
            "ROUNDED_CORNERS" => Style::RoundedCorners,
            "ROUNDED" => Style::Rounded,
            "NONE" => Style::None,
            _ => Style::Hotbar,
        },
        orientation: Orientation::from_name(&text(ids::ORIENTATION))
            .unwrap_or(Orientation::Horizontal),
        widget_shown: match text(ids::WIDGET_SHOWN).as_str() {
            "ALWAYS" => WidgetShown::Always,
            "IF_ANY_PRESENT" => WidgetShown::IfAnyPresent,
            _ => WidgetShown::NotEmpty,
        },
        offhand_slot_behavior: match text(ids::OFFHAND_SLOT_BEHAVIOR).as_str() {
            "ALWAYS_IGNORE" => OffhandSlotBehavior::AlwaysIgnore,
            "ALWAYS_LEAVE_SPACE" => OffhandSlotBehavior::AlwaysLeaveSpace,
            _ => OffhandSlotBehavior::Adhere,
        },
        durability_display: match text(ids::DURABILITY_DISPLAY).as_str() {
            "NUMBER" => DurabilityDisplay::Number,
            "PERCENTAGE" => DurabilityDisplay::Percentage,
            _ => DurabilityDisplay::Bar,
        },
        text_color: TextColor::from_name(&text(ids::TEXT_COLOR)),
        offhand_durability: runtime.bool(ids::OFFHAND_DURABILITY),
        mainhand_durability: runtime.bool(ids::MAINHAND_DURABILITY),
        push_bossbars: runtime.bool(ids::PUSH_BOSSBARS),
        push_status_effect_icons: runtime.bool(ids::PUSH_STATUS_EFFECT_ICONS),
        push_subtitles: runtime.bool(ids::PUSH_SUBTITLES),
        reversed: runtime.bool(ids::REVERSED),
        icons_shown: runtime.bool(ids::ICONS_SHOWN),
        warning_shown: runtime.bool(ids::WARNING_SHOWN),
        min_durability_value: runtime.int(ids::MIN_DURABILITY_VALUE),
        min_durability_percentage: runtime.float(ids::MIN_DURABILITY_PERCENTAGE),
        warning_icon_bobbing_interval_ms: runtime.int(ids::WARNING_ICON_BOBBING_INTERVAL_MS),
        warning_sound: runtime.bool(ids::WARNING_SOUND),
    }
}

// ---------------------------------------------------------------------------
// The HUD layout.
// ---------------------------------------------------------------------------

/// The geometry of the reference mods, in unscaled GUI pixels.
pub mod metrics {
    /// One slot's outer size (the hotbar row's height).
    pub const SIZE: f32 = 22.0;
    /// The distance between two slot icons.
    pub const STEP: f32 = 20.0;
    /// The item icon inside a slot.
    pub const ICON: f32 = 16.0;
    /// The icon's padding inside the slot.
    pub const ICON_PAD: f32 = 3.0;
    /// The warning mark's size.
    pub const WARNING: f32 = 8.0;
    /// The widget's distance from the hotbar's center (98 = 91 + 7).
    pub const HOTBAR_OFFSET: f32 = 98.0;
    /// The off-hand slot's width beside the hotbar.
    pub const OFFHAND: f32 = 29.0;
    /// The attack indicator's width beside the hotbar.
    pub const ATTACK_INDICATOR: f32 = 23.0;
    /// The bobbing amplitude of the warning mark.
    pub const BOB_AMPLITUDE: f32 = 3.0;
}

/// One computed frame of the widget: where it sits and what to draw.
pub struct HudLayout {
    /// The widget's bounding box, including the warning and durability
    /// extras (the "effective" rect of the reference).
    pub rect: Rect,
    /// The draw commands, in paint order. `DrawCmd::Item` indexes
    /// `stacks`.
    pub draws: Vec<DrawCmd>,
    /// The stacks the draw list refers to, in draw order.
    pub stacks: Vec<StackInfo>,
    /// Extra text drawn beside the vanilla hotbar (off-hand and main-hand
    /// durability), already positioned.
    pub hotbar_extras: Vec<DrawCmd>,
    /// The slots that show a warning this frame (`armor:0`… `armor:3`,
    /// `offhand`), in draw order — what the warning sound triggers on.
    pub warnings: Vec<String>,
    /// Which screen corner to reserve, when the settings ask for one.
    pub reserve_corner: Option<(tristanpbty_armor_hud_lib::utils::anchors::Anchor, Side)>,
    /// The bossbar displacement the widget asks for (pixels; applied by the
    /// host when an offset hook exists — reserved upstream for now).
    pub bossbar_push: f32,
    /// The subtitle displacement asked for (same reservation).
    pub subtitle_push: f32,
}

/// Computes the widget's position, as the reference's `getWidgetRect`.
pub fn widget_rect(settings: &Settings, snapshot: &EquipmentSnapshot, count: usize) -> Rect {
    let scale = settings.scale;
    let (size, step) = (metrics::SIZE * scale, metrics::STEP * scale);
    let texture_width = size + (count.saturating_sub(1) as f32) * step;
    let (w, h) = match settings.orientation {
        Orientation::Vertical => (size, texture_width),
        Orientation::Horizontal => (texture_width, size),
    };
    let (screen_w, screen_h) = (snapshot.screen[0], snapshot.screen[1]);

    // The reference's side multipliers: the hotbar's left and every other
    // anchor's right flip both the offset and the alignment.
    let (side_multiplier, side_offset_multiplier) = if (settings.anchor == Anchor::Hotbar
        && settings.side == Side::Left)
        || (settings.anchor != Anchor::Hotbar && settings.side == Side::Right)
    {
        (-1.0, -1.0)
    } else {
        (1.0, 0.0)
    };

    // The space the off-hand slot or the attack indicator takes beside the
    // hotbar, on the widget's side.
    let added = match settings.offhand_slot_behavior {
        OffhandSlotBehavior::AlwaysIgnore => 0.0,
        OffhandSlotBehavior::AlwaysLeaveSpace => {
            let main_arm_side = snapshot.right_handed == (settings.side == Side::Right);
            let base = if main_arm_side {
                metrics::ATTACK_INDICATOR
            } else {
                metrics::OFFHAND
            };
            base * scale
        }
        OffhandSlotBehavior::Adhere => {
            let main_arm_side = snapshot.right_handed == (settings.side == Side::Right);
            if main_arm_side {
                let indicator = snapshot.attack_indicator_hotbar && snapshot.attack_charging;
                if indicator {
                    metrics::ATTACK_INDICATOR * scale
                } else {
                    0.0
                }
            } else if snapshot.offhand.as_ref().is_some_and(|s| !s.is_empty()) {
                metrics::OFFHAND * scale
            } else {
                0.0
            }
        }
    };

    let x = settings.offset_x as f32 * side_multiplier
        + match settings.anchor {
            Anchor::TopCenter => (screen_w - w) / 2.0,
            Anchor::Top | Anchor::Center | Anchor::Bottom => {
                (w - screen_w) * side_offset_multiplier
            }
            Anchor::Hotbar => {
                screen_w / 2.0
                    + (metrics::HOTBAR_OFFSET * scale + added) * side_multiplier
                    + w * side_offset_multiplier
            }
        };
    let y = match settings.anchor {
        Anchor::Bottom | Anchor::Hotbar => screen_h - h - settings.offset_y as f32,
        Anchor::Top | Anchor::TopCenter => settings.offset_y as f32,
        Anchor::Center => (screen_h - h) / 2.0 + settings.offset_y as f32,
    };
    Rect::new(x, y, w, h)
}

/// The warning mark's bobbing offset at `now_ms`, deterministic (the
/// reference jitters randomly; a fixed cycle reads the same at a glance and
/// stays testable).
pub fn bob_offset(interval_ms: i64, now_ms: u64) -> f32 {
    if interval_ms <= 0 {
        return 0.0;
    }
    let phase = (now_ms % interval_ms as u64) as f32 / interval_ms as f32;
    (phase * std::f32::consts::TAU).sin() * metrics::BOB_AMPLITUDE
}

/// Computes the whole frame: slots, icons, durability and warnings.
pub fn hud_layout(settings: &Settings, snapshot: &EquipmentSnapshot) -> HudLayout {
    let mut layout = HudLayout {
        rect: Rect::new(0.0, 0.0, 0.0, 0.0),
        draws: Vec::new(),
        stacks: Vec::new(),
        hotbar_extras: Vec::new(),
        warnings: Vec::new(),
        reserve_corner: None,
        bossbar_push: 0.0,
        subtitle_push: 0.0,
    };
    if !settings.enabled {
        return layout;
    }
    let armor = snapshot.armor_order(settings.reversed);
    // Which slots the widget shows at all.
    let slots: Vec<(SlotKind, Option<&StackInfo>)> = match settings.widget_shown {
        WidgetShown::Always => armor,
        WidgetShown::IfAnyPresent if snapshot.any_armor() => armor,
        WidgetShown::NotEmpty => armor
            .into_iter()
            .filter(|(_, s)| s.is_some_and(|s| !s.is_empty()))
            .collect(),
        WidgetShown::IfAnyPresent => return layout,
    };
    if slots.is_empty() {
        return layout;
    }

    let scale = settings.scale;
    let (size, step, icon, pad) = (
        metrics::SIZE * scale,
        metrics::STEP * scale,
        metrics::ICON * scale,
        metrics::ICON_PAD * scale,
    );
    let rect = widget_rect(settings, snapshot, slots.len());
    layout.rect = effective_rect(settings, rect);

    // The slot backgrounds, cut from the vanilla hotbar sprites like the
    // reference's blitSprite regions.
    let texture_width = size + (slots.len().saturating_sub(1)) as f32 * step;
    draw_style(
        &mut layout.draws,
        settings.style,
        rect,
        texture_width,
        size,
        scale,
    );

    // The icons, the durability text and the warnings.
    let extras_side = if settings.anchor == Anchor::Hotbar {
        settings.side
    } else {
        settings.side.opposite()
    };
    for (i, (kind, stack)) in slots.iter().enumerate() {
        let (mut x, mut y) = (rect.x, rect.y);
        match settings.orientation {
            Orientation::Horizontal => x += step * i as f32,
            Orientation::Vertical => y += step * i as f32,
        }
        let empty = stack.is_none_or(|s| s.is_empty());
        if settings.icons_shown && empty {
            let name = format!("gui/sprites/container/slot/{}", kind.empty_icon());
            layout.draws.push(DrawCmd::Sprite {
                name,
                src: [0.0, 0.0, icon, icon],
                dst: [x + pad, y + pad, icon, icon],
                tint: tristanpbty_armor_hud_lib::utils::WHITE,
            });
        }
        if let Some(stack) = stack.filter(|s| !s.is_empty()) {
            let index = layout.stacks.len();
            layout.stacks.push(stack.clone());
            layout.draws.push(DrawCmd::Item {
                stack: index,
                at: [x + pad, y + pad],
                size: icon,
            });
        }
        // Where the durability text and the warning go.
        let mut tx = x;
        let mut ty = y;
        if settings.anchor.is_top() && settings.orientation == Orientation::Horizontal {
            ty += size;
        } else if extras_side == Side::Right && settings.orientation == Orientation::Vertical {
            tx += size;
        }
        if let Some(stack) = stack.filter(|s| !s.is_empty()) {
            if settings.durability_display != DurabilityDisplay::Bar && stack.is_damageable() {
                let text = stack
                    .durability_text(settings.durability_display == DurabilityDisplay::Percentage);
                let color = settings.text_color.rgb(stack.ratio());
                push_text(
                    &mut layout.draws,
                    &text,
                    tx,
                    ty,
                    color,
                    settings.orientation,
                    extras_side,
                    x,
                    size,
                    scale,
                    true,
                );
            }
            if settings.warning_shown
                && stack.needs_warning(
                    settings.min_durability_value,
                    settings.min_durability_percentage,
                )
            {
                let bob = bob_offset(settings.warning_icon_bobbing_interval_ms, snapshot.now_ms);
                layout.warnings.push(format!("armor:{kind:?}"));
                draw_warning(
                    &mut layout.draws,
                    tx,
                    ty + bob,
                    settings.orientation,
                    extras_side,
                    size,
                    scale,
                );
            }
        }
    }

    // The off-hand and main-hand durability text beside the vanilla hotbar,
    // exactly where the reference puts it.
    hotbar_extras(
        &mut layout.hotbar_extras,
        &mut layout.warnings,
        settings,
        snapshot,
    );

    // Corner reservation for the status effect rows: only the TOP anchor
    // shares the screen's top corners with them.
    if settings.anchor == Anchor::Top && settings.push_status_effect_icons {
        layout.reserve_corner = Some((Anchor::Top, settings.side));
    }
    // What the bossbars and subtitles would be pushed by (reserved).
    if settings.push_bossbars && settings.anchor == Anchor::TopCenter {
        layout.bossbar_push = layout.rect.h + 2.0;
    }
    if settings.push_subtitles && settings.anchor == Anchor::Bottom && settings.side == Side::Right
    {
        layout.subtitle_push = layout.rect.h + 2.0;
    }
    layout
}

/// The widget's effective rect: the slot row plus the warning and durability
/// extras hanging off it.
fn effective_rect(settings: &Settings, rect: Rect) -> Rect {
    let mut out = rect;
    let extra = if settings.warning_shown {
        metrics::WARNING * settings.scale + 2.0
    } else {
        0.0
    } + if settings.durability_display != DurabilityDisplay::Bar {
        8.0 * settings.scale
    } else {
        0.0
    };
    if extra <= 0.0 {
        return out;
    }
    match (settings.anchor.is_top(), settings.orientation) {
        (true, Orientation::Horizontal) => out.h += extra,
        (false, Orientation::Horizontal) => {
            out.y -= extra;
            out.h += extra;
        }
        (_, Orientation::Vertical) => out.w += extra,
    }
    out
}

/// Draws the slot background of `style` as sprite regions of the vanilla
/// hotbar textures, like the reference.
///
/// The names are the HUD atlas's full keys (`gui/sprites/hud/hotbar`, the
/// texture's path under `textures/`): `native_sprite` looks the name up in
/// the atlas directly, unlike Horizon's own `hud_layout`, whose short ids
/// (`hud/hotbar`) only work because its `paint` adds the `gui/sprites/`
/// prefix itself. A short id here fails the lookup and draws nothing.
fn draw_style(
    out: &mut Vec<DrawCmd>,
    style: Style,
    rect: Rect,
    texture_width: f32,
    size: f32,
    scale: f32,
) {
    let hotbar = "gui/sprites/hud/hotbar";
    let offhand_left = "gui/sprites/hud/hotbar_offhand_left";
    match style {
        Style::None => {}
        Style::Hotbar => {
            out.push(DrawCmd::Sprite {
                name: hotbar.to_string(),
                src: [0.0, 0.0, (texture_width / scale - 3.0).max(1.0), 22.0],
                dst: [
                    rect.x,
                    rect.y,
                    (texture_width - 3.0 * scale).max(scale),
                    size,
                ],
                tint: tristanpbty_armor_hud_lib::utils::WHITE,
            });
            out.push(DrawCmd::Sprite {
                name: hotbar.to_string(),
                src: [182.0 - 3.0, 0.0, 3.0, 22.0],
                dst: [
                    rect.x + texture_width - 3.0 * scale,
                    rect.y,
                    3.0 * scale,
                    size,
                ],
                tint: tristanpbty_armor_hud_lib::utils::WHITE,
            });
        }
        Style::RoundedCorners => {
            if texture_width / scale > size / scale {
                out.push(DrawCmd::Sprite {
                    name: offhand_left.to_string(),
                    src: [0.0, 1.0, 3.0, 22.0],
                    dst: [rect.x, rect.y, 3.0 * scale, size],
                    tint: tristanpbty_armor_hud_lib::utils::WHITE,
                });
                out.push(DrawCmd::Sprite {
                    name: hotbar.to_string(),
                    src: [3.0, 0.0, (texture_width / scale - 6.0).max(1.0), 22.0],
                    dst: [
                        rect.x + 3.0 * scale,
                        rect.y,
                        (texture_width - 6.0 * scale).max(scale),
                        size,
                    ],
                    tint: tristanpbty_armor_hud_lib::utils::WHITE,
                });
                out.push(DrawCmd::Sprite {
                    name: offhand_left.to_string(),
                    src: [22.0 - 3.0, 1.0, 3.0, 22.0],
                    dst: [
                        rect.x + texture_width - 3.0 * scale,
                        rect.y,
                        3.0 * scale,
                        size,
                    ],
                    tint: tristanpbty_armor_hud_lib::utils::WHITE,
                });
            } else {
                out.push(DrawCmd::Sprite {
                    name: offhand_left.to_string(),
                    src: [0.0, 1.0, 22.0, 22.0],
                    dst: [rect.x, rect.y, size, size],
                    tint: tristanpbty_armor_hud_lib::utils::WHITE,
                });
            }
        }
        Style::Rounded => {
            let count = (texture_width / metrics::STEP / scale).round() as i32;
            if count > 1 {
                let border = (size / scale - metrics::STEP) / 2.0;
                out.push(DrawCmd::Sprite {
                    name: offhand_left.to_string(),
                    src: [0.0, 1.0, size / scale - border, 22.0],
                    dst: [rect.x, rect.y, size - border * scale, size],
                    tint: tristanpbty_armor_hud_lib::utils::WHITE,
                });
                for i in 1..count.saturating_sub(1) {
                    out.push(DrawCmd::Sprite {
                        name: offhand_left.to_string(),
                        src: [border, 1.0, metrics::STEP, 22.0],
                        dst: [
                            rect.x + (border + i as f32 * metrics::STEP) * scale,
                            rect.y,
                            metrics::STEP * scale,
                            size,
                        ],
                        tint: tristanpbty_armor_hud_lib::utils::WHITE,
                    });
                }
                out.push(DrawCmd::Sprite {
                    name: offhand_left.to_string(),
                    src: [1.0, 1.0, size / scale - metrics::STEP - border, 22.0],
                    dst: [
                        rect.x + texture_width - (size - border * scale),
                        rect.y,
                        size - border * scale,
                        size,
                    ],
                    tint: tristanpbty_armor_hud_lib::utils::WHITE,
                });
            } else {
                out.push(DrawCmd::Sprite {
                    name: offhand_left.to_string(),
                    src: [0.0, 1.0, 22.0, 22.0],
                    dst: [rect.x, rect.y, size, size],
                    tint: tristanpbty_armor_hud_lib::utils::WHITE,
                });
            }
        }
    }
}

/// The reference's warning mark, pixel for pixel: `warn.png` of
/// uku3lig/armor-hud (MIT) — the red dome with white stripes that also sits
/// atop the mod's logo. A source-only `.hnmod` ships no textures, so the
/// 8×8 grid is drawn with plain fills, one rectangle per run of equal
/// pixels.
pub mod warn_mark {
    /// `warn.png`'s exact 8×8 grid, row-major; `0` is transparent.
    pub const TEXTURE: [[u32; 8]; 8] = [
        [
            0,
            0,
            0xFF9D_0D0D,
            0xFF9D_0D0D,
            0xFF9D_0D0D,
            0xFF9D_0D0D,
            0,
            0,
        ],
        [
            0,
            0xFFE4_B9B9,
            0xFFDD_3232,
            0xFFEA_BDBD,
            0xFFD2_2323,
            0xFFE4_B9B9,
            0xFF8C_0B0B,
            0,
        ],
        [
            0xFF9D_0D0D,
            0xFFEA_BDBD,
            0xFFD2_2323,
            0xFFE4_B9B9,
            0xFFB9_0F0F,
            0xFFE4_B9B9,
            0xFFB9_0F0F,
            0xFF74_0A0A,
        ],
        [
            0xFF9D_0D0D,
            0xFFEA_BDBD,
            0xFFB9_0F0F,
            0xFFE4_B9B9,
            0xFFB9_0F0F,
            0xFFE4_B9B9,
            0xFFB9_0F0F,
            0xFF74_0A0A,
        ],
        [
            0xFF9D_0D0D,
            0xFFD2_2323,
            0xFFB9_0F0F,
            0xFFB9_0F0F,
            0xFFB9_0F0F,
            0xFFB9_0F0F,
            0xFFB9_0F0F,
            0xFF74_0A0A,
        ],
        [
            0xFF9D_0D0D,
            0xFFE4_B9B9,
            0xFFB9_0F0F,
            0xFFE4_B9B9,
            0xFFB9_0F0F,
            0xFFE4_B9B9,
            0xFFB9_0F0F,
            0xFF74_0A0A,
        ],
        [
            0,
            0xFF8C_0B0B,
            0xFFB9_0F0F,
            0xFFB9_0F0F,
            0xFFB9_0F0F,
            0xFFB9_0F0F,
            0xFF74_0A0A,
            0,
        ],
        [
            0,
            0,
            0xFF74_0A0A,
            0xFF74_0A0A,
            0xFF74_0A0A,
            0xFF74_0A0A,
            0,
            0,
        ],
    ];

    /// The fills that paint `TEXTURE` with its top-left at (`x`, `y`) and
    /// pixels of `px` GUI units: one rectangle per horizontal run of equal
    /// pixels, so the whole mark costs at most a few dozen quads. Each fill
    /// is the `[x, y, w, h]` a `DrawCmd::Fill` takes.
    pub fn fills(x: f32, y: f32, px: f32) -> Vec<([f32; 4], u32)> {
        let mut out = Vec::new();
        for (row, line) in TEXTURE.iter().enumerate() {
            let mut col = 0;
            while col < line.len() {
                let color = line[col];
                if color == 0 {
                    col += 1;
                    continue;
                }
                let start = col;
                while col < line.len() && line[col] == color {
                    col += 1;
                }
                out.push((
                    [
                        x + start as f32 * px,
                        y + row as f32 * px,
                        (col - start) as f32 * px,
                        px,
                    ],
                    color,
                ));
            }
        }
        out
    }
}

/// The warning mark: the reference's `warn.png` dome, bobbing when asked.
/// Drawn as fills (see [`warn_mark`]) — a text glyph reads nothing like the
/// original.
fn draw_warning(
    out: &mut Vec<DrawCmd>,
    x: f32,
    y: f32,
    orientation: Orientation,
    extras_side: Side,
    size: f32,
    scale: f32,
) {
    let edge = metrics::WARNING * scale;
    let (mx, my) = if orientation == Orientation::Horizontal {
        (x + size / 2.0 - edge / 2.0, y + 1.0)
    } else {
        let left = if extras_side == Side::Left {
            x - edge - 2.0
        } else {
            x + size + 2.0
        };
        (left, y + size / 2.0 - edge / 2.0)
    };
    for (rect, argb) in warn_mark::fills(mx, my, scale) {
        out.push(DrawCmd::Fill { rect, argb });
    }
}

/// Places the durability text beside its slot, as the reference does.
#[allow(clippy::too_many_arguments)]
fn push_text(
    out: &mut Vec<DrawCmd>,
    text: &str,
    x: f32,
    y: f32,
    color: u32,
    orientation: Orientation,
    extras_side: Side,
    slot_x: f32,
    size: f32,
    scale: f32,
    centered: bool,
) {
    if orientation == Orientation::Horizontal {
        if centered {
            out.push(DrawCmd::Text {
                text: text.to_string(),
                at: [0.0, y],
                rgb: color,
                shadow: true,
                center_x: Some(slot_x + size / 2.0),
            });
        } else {
            out.push(DrawCmd::Text {
                text: text.to_string(),
                at: [x, y],
                rgb: color,
                shadow: true,
                center_x: None,
            });
        }
    } else {
        let tx = if extras_side == Side::Left {
            x - 24.0 * scale
        } else {
            x + size + 2.0 * scale
        };
        out.push(DrawCmd::Text {
            text: text.to_string(),
            at: [tx, y + size / 2.0 - 4.0 * scale],
            rgb: color,
            shadow: true,
            center_x: None,
        });
    }
}

/// The durability text and warnings beside the vanilla hotbar slots, where
/// the reference's `renderMainAndOffhand` puts them.
fn hotbar_extras(
    out: &mut Vec<DrawCmd>,
    warnings: &mut Vec<String>,
    settings: &Settings,
    snapshot: &EquipmentSnapshot,
) {
    let scale = settings.scale;
    let center = snapshot.screen[0] / 2.0;
    let height = snapshot.screen[1];
    if let Some(offhand) = snapshot.offhand.as_ref().filter(|s| !s.is_empty())
        && settings.offhand_durability
        && offhand.is_damageable()
    {
        // The off-hand slot sits 29 pixels wide beside the hotbar, on
        // the arm opposite the main one.
        let x = if snapshot.right_handed {
            center - 91.0 - 29.0
        } else {
            center + 91.0 + 7.0
        };
        let mut y = height - metrics::SIZE * scale;
        if settings.durability_display != DurabilityDisplay::Bar {
            let text = offhand
                .durability_text(settings.durability_display == DurabilityDisplay::Percentage);
            y -= 8.0 * scale;
            out.push(DrawCmd::Text {
                text,
                at: [0.0, y],
                rgb: settings.text_color.rgb(offhand.ratio()),
                shadow: true,
                center_x: Some(x + metrics::SIZE * scale / 2.0),
            });
        }
        if settings.warning_shown
            && offhand.needs_warning(
                settings.min_durability_value,
                settings.min_durability_percentage,
            )
        {
            y -= metrics::WARNING * scale + 2.0;
            y += bob_offset(settings.warning_icon_bobbing_interval_ms, snapshot.now_ms);
            warnings.push("offhand".to_string());
            let cx = x + metrics::SIZE * scale / 2.0;
            for (rect, argb) in warn_mark::fills(cx - metrics::WARNING * scale / 2.0, y, scale) {
                out.push(DrawCmd::Fill { rect, argb });
            }
        }
    }
    if let Some(main) = snapshot.main_hand.as_ref().filter(|s| !s.is_empty())
        && settings.mainhand_durability
        && main.is_damageable()
        && settings.durability_display != DurabilityDisplay::Bar
    {
        let x = center - 91.0 + snapshot.selected as f32 * 20.0 + metrics::SIZE * scale / 2.0;
        let y = height - metrics::SIZE * scale - 1.0;
        let text =
            main.durability_text(settings.durability_display == DurabilityDisplay::Percentage);
        out.push(DrawCmd::Text {
            text,
            at: [0.0, y],
            rgb: settings.text_color.rgb(main.ratio()),
            shadow: true,
            center_x: Some(x),
        });
    }
}

// ---------------------------------------------------------------------------
// The mod's state and the host API.
// ---------------------------------------------------------------------------

/// What the host should do after a key event.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Action {
    /// Open (or close) the mod's configuration screen.
    ToggleScreen,
    None,
}

/// The configuration screen's state.
pub struct ScreenState {
    pub tab: usize,
    /// The active tab's settings, one plain cycling button each.
    pub controls: Vec<CycleButton>,
    /// The Done button under them, the screen's one action button.
    pub done: Button,
    /// The screen panel, recomputed each draw.
    pub panel: Rect,
    /// The last cursor position seen, for hover states.
    pub cursor: [f32; 2],
    /// Set once the game has actually drawn the screen: the frame hook
    /// then knows a game side that stops showing it means Escape, not the
    /// open still settling.
    pub seen: bool,
    /// Set when the Done button is clicked: the frame hook then asks the
    /// game to close the screen (only it can).
    pub want_close: bool,
}

/// The mod's whole state. Behind a mutex because Horizon's screen hooks
/// hand out the game immutably; the render thread is the only visitor.
pub struct ModState {
    pub runtime: ConfigRuntime,
    pub screen: Option<ScreenState>,
    /// The key that opens the screen, from the game's own mod-key storage
    /// (`horizon-mods.txt`), read by the host each key event.
    pub menu_key: String,
    /// The host's clock, advanced by the frame hook.
    pub now_ms: u64,
    /// The slots that warned recently, with when each was last seen
    /// warning (`armor:Head`… `offhand`): a slot keeps counting as warning
    /// for [`WARNING_SOUND_COOLDOWN_MS`] after it last did, so mending's
    /// flicker cannot retrigger the sound.
    pub warning_slots: Vec<(String, u64)>,
    pub log: Vec<String>,
}

impl ModState {
    fn new() -> ModState {
        ModState {
            runtime: ConfigRuntime::in_memory(&schema::SCHEMA),
            screen: None,
            menu_key: DEFAULT_MENU_KEY.to_string(),
            now_ms: 0,
            warning_slots: Vec::new(),
            log: Vec::new(),
        }
    }
}

/// The mod's state.
pub fn state() -> &'static Mutex<ModState> {
    static STATE: OnceLock<Mutex<ModState>> = OnceLock::new();
    STATE.get_or_init(|| Mutex::new(ModState::new()))
}

/// Notifies the state of the slots warning this frame and says whether the
/// host should play the break sound: once per warning that newly appears —
/// not on every frame it stays. A slot that stops warning still counts as
/// warning for [`WARNING_SOUND_COOLDOWN_MS`], so a piece swinging back over
/// the threshold (mending) cannot rattle the sound; a genuinely new one
/// always plays. Called by the HUD helper with the real frame's warnings.
pub fn notice_warnings(warnings: &[String], sound_on: bool) -> bool {
    let mut state = state().lock().unwrap();
    let now = state.now_ms;
    let remembered = |slot: &str| {
        state
            .warning_slots
            .iter()
            .any(|(seen, at)| seen == slot && now.saturating_sub(*at) <= WARNING_SOUND_COOLDOWN_MS)
    };
    let appeared = warnings.iter().any(|slot| !remembered(slot));
    // Refresh the entries that still warn, keep those that left within the
    // cooldown (mending's flicker), forget the rest.
    let mut kept: Vec<(String, u64)> = state
        .warning_slots
        .iter()
        .filter(|(_, at)| now.saturating_sub(*at) <= WARNING_SOUND_COOLDOWN_MS)
        .cloned()
        .collect();
    for slot in warnings {
        if let Some(entry) = kept.iter_mut().find(|(seen, _)| seen == slot) {
            entry.1 = now;
        } else {
            kept.push((slot.clone(), now));
        }
    }
    state.warning_slots = kept;
    sound_on && appeared
}

/// Attaches the configuration file, called once from the first HUD draw
/// (the config folder only exists once the game folder is known).
pub fn init_storage(config_dir: PathBuf) {
    let mut state = state().lock().unwrap();
    if state.runtime.path().is_some() {
        return;
    }
    let path = config_dir.join("tristanpbty_armor_hud.json");
    let runtime = ConfigRuntime::with_storage(
        &schema::SCHEMA,
        Box::new(FsDisk) as Box<dyn Disk>,
        path,
        &[],
    );
    state.log.extend(runtime.load_report.iter().cloned());
    state.runtime = runtime;
}

/// The panel geometry of the configuration screen for a window of
/// `screen` GUI pixels: wide enough for a tab bar of plain buttons, tall
/// enough for the largest tab (six entries), small enough for the shortest
/// windows the GUI scale allows.
pub fn screen_panel(screen: [f32; 2]) -> Rect {
    let (w, h) = (300.0, 216.0);
    Rect::new(
        ((screen[0] - w) / 2.0).max(4.0),
        ((screen[1] - h) / 2.0).max(4.0),
        w,
        h,
    )
}

/// Opens the configuration screen on its first tab.
pub fn open_screen() {
    let mut state = state().lock().unwrap();
    state.screen = Some(ScreenState {
        tab: 0,
        controls: Vec::new(),
        done: Button::new("done", "Done", "close", Rect::new(0.0, 0.0, 0.0, 0.0)),
        // A sane default until the first draw measures the real window.
        panel: screen_panel([640.0, 480.0]),
        cursor: [0.0, 0.0],
        seen: false,
        want_close: false,
    });
    if let Some(screen) = state.screen.as_mut() {
        rebuild_controls(screen);
    }
}

/// Closes the configuration screen, saving at once.
pub fn close_screen() {
    let mut state = state().lock().unwrap();
    let now = state.now_ms;
    if state.screen.take().is_some() {
        state.runtime.save(now);
    }
}

/// Resets every setting to its default and saves at once — the mod manager's
/// reset button. The screen, when one is open, rebuilds on its next draw.
pub fn reset_settings() {
    let mut state = state().lock().unwrap();
    let now = state.now_ms;
    state.runtime.reset();
    state.runtime.save(now);
    if let Some(screen) = state.screen.as_mut() {
        rebuild_controls(screen);
    }
    state
        .log
        .push("settings reset to their defaults".to_string());
}

/// Rebuilds the active tab's controls: one plain cycling button per entry,
/// full width, and the Done button under them.
fn rebuild_controls(screen: &mut ScreenState) {
    let tab = &schema::SCHEMA.tabs[screen.tab.min(schema::SCHEMA.tabs.len() - 1)];
    screen.controls.clear();
    let mut y = screen.panel.y + 50.0;
    for entry in tab.entries {
        let rect = Rect::new(screen.panel.x + 8.0, y, screen.panel.w - 16.0, 20.0);
        screen
            .controls
            .push(CycleButton::new(entry.id, entry.label, rect));
        y += 22.0;
    }
    let center = screen.panel.center();
    screen.done = Button::new(
        "done",
        "Done",
        "close",
        Rect::new(center[0] - 50.0, screen.panel.y + 188.0, 100.0, 20.0),
    );
}

/// Advances the clock and saves when a change has settled. Returns the
/// number of milliseconds to give `ConfigRuntime::tick`.
pub fn frame(elapsed_ms: u64) {
    let mut state = state().lock().unwrap();
    state.now_ms = state.now_ms.saturating_add(elapsed_ms);
    let now = state.now_ms;
    state.runtime.tick(now);
}

/// Handles a named key event from the game. The menu key toggles the
/// configuration screen; everything else goes to the open screen's widgets.
pub fn key(name: &str, pressed: bool) -> Action {
    if !pressed {
        return Action::None;
    }
    if name == state().lock().unwrap().menu_key {
        return Action::ToggleScreen;
    }
    Action::None
}

/// Feeds an input event to the open configuration screen. Returns true when
/// the screen consumed it (the host then cancels the screen's own handling).
pub fn screen_input(event: &InputEvent<'_>) -> bool {
    let mut state = state().lock().unwrap();
    let ModState {
        runtime, screen, ..
    } = &mut *state;
    let Some(screen) = screen.as_mut() else {
        return false;
    };
    if let InputEvent::Key { name, .. } = event
        && *name == "key.keyboard.tab"
    {
        screen.tab = (screen.tab + 1) % schema::SCHEMA.tabs.len();
        rebuild_controls(screen);
        return true;
    }
    // The setting buttons, topmost first.
    let mut consumed = false;
    for control in screen.controls.iter_mut().rev() {
        let result = control.input(event, runtime);
        if result.consumed {
            consumed = true;
            break;
        }
    }
    // The Done button: it only asks — the frame hook closes the game's
    // screen, which the input path cannot reach.
    if !consumed {
        let result = screen.done.input(event, runtime);
        if result.consumed {
            consumed = true;
            if screen.done.last_action.as_deref() == Some("close") {
                screen.want_close = true;
            }
        }
    }
    if !consumed {
        // The tab bar.
        if let InputEvent::Press { pos, button: 0 } = event {
            let bar = tab_bar_rect(screen.panel);
            if bar.contains(*pos) {
                let index =
                    ((pos[0] - bar.x) / (bar.w / schema::SCHEMA.tabs.len() as f32)) as usize;
                if index < schema::SCHEMA.tabs.len() {
                    screen.tab = index;
                    rebuild_controls(screen);
                    consumed = true;
                }
            }
        }
    }
    consumed
}

fn tab_bar_rect(panel: Rect) -> Rect {
    Rect::new(panel.x + 8.0, panel.y + 32.0, panel.w - 16.0, 14.0)
}

/// The frame hook's side of the screen: saves and clears the mod's own
/// state whenever the screen stops being shown — the Done button's
/// request, or the game closing it itself (the Escape key). Returns true
/// when the game still shows the screen and should now close it: the Done
/// button's case, the one path that has to go back into the game.
pub fn screen_reconcile(game_shows_screen: bool) -> bool {
    let mut state = state().lock().unwrap();
    let close_game = game_shows_screen
        && state
            .screen
            .as_ref()
            .is_some_and(|screen| screen.want_close);
    // A screen the game no longer shows is saved and cleared — but only
    // once the game has actually shown it, so a screen still opening is
    // not closed by mistake.
    if close_game || (state.screen.as_ref().is_some_and(|s| s.seen) && !game_shows_screen) {
        let now = state.now_ms;
        if state.screen.take().is_some() {
            state.runtime.save(now);
        }
    }
    close_game
}

/// Draws the configuration screen: the header (the mod's emblem beside its
/// name), the tab bar, and the active tab's settings as plain cycling
/// buttons — one button per line, its value worn on it — with the Done
/// button under them. No preview: the settings act on the HUD behind the
/// screen the moment they change.
pub fn screen_draw(screen_size: [f32; 2], cursor: [f32; 2]) -> Vec<DrawCmd> {
    let mut out = Vec::new();
    let mut state = state().lock().unwrap();
    let ModState {
        runtime, screen, ..
    } = &mut *state;
    let Some(screen) = screen.as_mut() else {
        return out;
    };
    let panel = screen_panel(screen_size);
    if screen.panel != panel {
        // The window changed size (or this is the first draw): relayout.
        screen.panel = panel;
        rebuild_controls(screen);
    }
    screen.seen = true;
    screen.cursor = cursor;
    let runtime = &*runtime;
    out.push(DrawCmd::Fill {
        rect: [panel.x, panel.y, panel.w, panel.h],
        argb: tristanpbty_armor_hud_lib::widgets::PANEL,
    });
    tristanpbty_armor_hud_lib::widgets::draw_border(
        &mut out,
        panel,
        tristanpbty_armor_hud_lib::widgets::BORDER,
    );

    // The header: the mod's emblem — the vanilla turtle helmet — beside its
    // name, over a rule that parts it from the tabs. The `Item` command is
    // the screen's only one: the host helper resolves it to `MOD_LOGO_ITEM`.
    out.push(DrawCmd::Item {
        stack: 0,
        at: [panel.x + 10.0, panel.y + 8.0],
        size: 16.0,
    });
    out.push(DrawCmd::Text {
        text: MOD_NAME.to_string(),
        at: [panel.x + 32.0, panel.y + 11.0],
        rgb: tristanpbty_armor_hud_lib::widgets::TEXT,
        shadow: true,
        center_x: None,
    });
    out.push(DrawCmd::Fill {
        rect: [panel.x + 10.0, panel.y + 28.0, panel.w - 20.0, 1.0],
        argb: tristanpbty_armor_hud_lib::widgets::BORDER,
    });

    // The tab bar: plain buttons, the active one accented.
    let bar = tab_bar_rect(panel);
    let tab_w = bar.w / schema::SCHEMA.tabs.len() as f32;
    for (i, tab) in schema::SCHEMA.tabs.iter().enumerate() {
        let rect = Rect::new(bar.x + i as f32 * tab_w, bar.y, tab_w - 1.0, bar.h);
        let active = i == screen.tab;
        out.push(DrawCmd::Fill {
            rect: [rect.x, rect.y, rect.w, rect.h],
            argb: if active {
                tristanpbty_armor_hud_lib::widgets::ACCENT
            } else {
                tristanpbty_armor_hud_lib::widgets::TRACK
            },
        });
        out.push(DrawCmd::Text {
            text: tab.label.to_string(),
            at: [0.0, rect.y + 3.0],
            rgb: tristanpbty_armor_hud_lib::widgets::TEXT,
            shadow: true,
            center_x: Some(rect.center()[0]),
        });
    }

    // The settings: one cycling button per entry of the active tab.
    for control in &screen.controls {
        control.draw(&mut out, control.rect().contains(cursor), runtime);
    }

    // Done, centered under them.
    screen
        .done
        .draw(&mut out, screen.done.rect().contains(cursor), runtime);
    out
}

/// Moves a draw list by `(dx, dy)`.
pub fn translate_draws(draws: &mut [DrawCmd], by: [f32; 2]) {
    for draw in draws.iter_mut() {
        match draw {
            DrawCmd::Fill { rect, .. } => {
                rect[0] += by[0];
                rect[1] += by[1];
            }
            DrawCmd::Sprite { dst, .. } => {
                dst[0] += by[0];
                dst[1] += by[1];
            }
            DrawCmd::Text { at, center_x, .. } => {
                at[0] += by[0];
                at[1] += by[1];
                if let Some(cx) = center_x {
                    *cx += by[0];
                }
            }
            DrawCmd::Item { at, .. } => {
                at[0] += by[0];
                at[1] += by[1];
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Tests.
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    fn settings() -> Settings {
        Settings {
            enabled: true,
            anchor: Anchor::Hotbar,
            side: Side::Left,
            offset_x: 0,
            offset_y: 0,
            scale: 1.0,
            style: Style::Hotbar,
            orientation: Orientation::Horizontal,
            widget_shown: WidgetShown::NotEmpty,
            offhand_slot_behavior: OffhandSlotBehavior::Adhere,
            durability_display: DurabilityDisplay::Bar,
            text_color: TextColor::Auto,
            offhand_durability: true,
            mainhand_durability: false,
            push_bossbars: true,
            push_status_effect_icons: true,
            push_subtitles: true,
            reversed: false,
            icons_shown: true,
            warning_shown: true,
            min_durability_value: 20,
            min_durability_percentage: 0.1,
            warning_icon_bobbing_interval_ms: 2000,
            warning_sound: true,
        }
    }

    fn snapshot() -> EquipmentSnapshot {
        let item = |name: &str, damage: u32, max: u32| StackInfo {
            item: name.to_string(),
            count: 1,
            damage,
            max_damage: max,
            glint: false,
        };
        EquipmentSnapshot {
            armor: [
                Some(item("minecraft:iron_helmet", 20, 165)),
                Some(item("minecraft:diamond_chestplate", 500, 528)),
                None,
                None,
            ],
            offhand: None,
            main_hand: None,
            selected: 0,
            right_handed: true,
            attack_indicator_hotbar: false,
            attack_charging: false,
            screen: [400.0, 300.0],
            now_ms: 0,
        }
    }

    #[test]
    fn hotbar_anchor_places_the_widget_left_of_the_hotbar() {
        let s = settings();
        let snap = snapshot();
        // Two of four armor slots filled at NOT_EMPTY: an 42-pixel-wide row.
        let rect = widget_rect(&s, &snap, 2);
        assert_eq!(rect.w, 22.0 + 20.0);
        assert_eq!(rect.h, 22.0);
        // Left of the hotbar's left edge (200 - 91 = 109), level with it:
        // the widget's bottom rests on the screen's bottom, like the row it
        // stands beside.
        assert!(rect.right() <= 109.0, "{:?}", rect);
        assert_eq!(rect.y, 300.0 - 22.0);
        assert_eq!(rect.x, 400.0 / 2.0 - 98.0 - rect.w);
    }

    #[test]
    fn offhand_adhere_leaves_space_only_when_needed() {
        let mut s = settings();
        let mut snap = snapshot();
        // Empty off-hand: no extra space.
        let plain = widget_rect(&s, &snap, 4);
        // An occupied off-hand moves the widget 29 pixels further out.
        snap.offhand = Some(StackInfo {
            item: "minecraft:shield".into(),
            count: 1,
            damage: 0,
            max_damage: 336,
            glint: false,
        });
        let pushed = widget_rect(&s, &snap, 4);
        assert_eq!(plain.x - pushed.x, 29.0);
        // ALWAYS_IGNORE ignores it.
        s.offhand_slot_behavior = OffhandSlotBehavior::AlwaysIgnore;
        assert_eq!(widget_rect(&s, &snap, 4).x, plain.x);
        // ALWAYS_LEAVE_SPACE keeps the gap even empty.
        snap.offhand = None;
        s.offhand_slot_behavior = OffhandSlotBehavior::AlwaysLeaveSpace;
        assert_eq!(widget_rect(&s, &snap, 4).x, pushed.x);
    }

    #[test]
    fn not_empty_hides_the_widget_without_armor() {
        let s = settings();
        let mut snap = snapshot();
        snap.armor = [None, None, None, None];
        let layout = hud_layout(&s, &snap);
        assert!(layout.draws.is_empty());
        // IF_ANY_PRESENT also hides it.
        let mut s2 = s.clone();
        s2.widget_shown = WidgetShown::IfAnyPresent;
        assert!(hud_layout(&s2, &snap).draws.is_empty());
        // ALWAYS draws it.
        s2.widget_shown = WidgetShown::Always;
        assert!(!hud_layout(&s2, &snap).draws.is_empty());
    }

    #[test]
    fn layout_draws_slots_icons_and_warnings() {
        let s = settings();
        let layout = hud_layout(&s, &snapshot());
        // Two filled slots: two Item commands.
        assert_eq!(layout.stacks.len(), 2);
        assert_eq!(
            layout
                .draws
                .iter()
                .filter(|d| matches!(d, DrawCmd::Item { .. }))
                .count(),
            2
        );
        // The chestplate at 28 of 528 left (5%) warns; the helmet at 88%
        // does not, so exactly one warning — recorded as a slot key, drawn
        // as the reference's warn mark, and the mark's fills are the only
        // non-durability-bar fills on the frame.
        assert_eq!(layout.warnings, ["armor:Chest".to_string()]);
        let marks = |layout: &HudLayout| {
            layout
                .draws
                .iter()
                .filter(|d| matches!(d, DrawCmd::Fill { argb, .. } if argb == &0xFFE4_B9B9))
                .count()
        };
        // Each mark paints exactly the white stripes of `warn.png`'s grid.
        let stripes = warn_mark::TEXTURE
            .iter()
            .map(|row| row.iter().filter(|&&c| c == 0xFFE4_B9B9).count())
            .sum::<usize>();
        assert!(stripes > 0);
        assert_eq!(marks(&layout), stripes);
        // A pristine chestplate leaves no warning at all.
        let mut snap = snapshot();
        if let Some(chest) = snap.armor[1].as_mut() {
            chest.damage = 0;
        }
        assert_eq!(marks(&hud_layout(&s, &snap)), 0);
        assert!(hud_layout(&s, &snap).warnings.is_empty());
        // A nearly broken helmet warns again.
        snap.armor[0].as_mut().unwrap().damage = 160;
        assert_eq!(marks(&hud_layout(&s, &snap)), stripes);
        assert_eq!(hud_layout(&s, &snap).warnings, ["armor:Head".to_string()]);
    }

    #[test]
    fn warning_mark_paints_the_reference_texture() {
        // The fills tile `warn.png`'s grid exactly: same colors, same pixels,
        // merged only along runs — the reference's own warning mark, drawn
        // with rectangles because a source bundle ships no textures.
        let fills = warn_mark::fills(10.0, 20.0, 1.0);
        let mut painted = [[0u32; 8]; 8];
        for (rect, argb) in &fills {
            let [x, y, w, h] = *rect;
            assert_eq!(h as usize, 1);
            let (x, y, w) = (x as usize - 10, y as usize - 20, w as usize);
            for dx in 0..w {
                painted[y][x + dx] = *argb;
            }
        }
        assert_eq!(painted, warn_mark::TEXTURE);
        // At double scale the grid doubles, pixel for pixel.
        let fills = warn_mark::fills(0.0, 0.0, 2.0);
        assert!(
            fills
                .iter()
                .all(|([_, _, w, h], _)| w % 2.0 == 0.0 && *h == 2.0)
        );
    }

    #[test]
    fn warning_sound_plays_once_per_appearance() {
        fn reset() {
            let mut state = state().lock().unwrap();
            state.now_ms = 10_000;
            state.warning_slots = Vec::new();
        }
        // A warning appears: play.
        reset();
        assert!(notice_warnings(&["armor:Head".into()], true));
        // The same warning stays: quiet.
        assert!(!notice_warnings(&["armor:Head".into()], true));
        // A second slot joins it: play for that one too.
        assert!(notice_warnings(
            &["armor:Head".into(), "offhand".into()],
            true
        ));
        // Everything heals (mending): the keys leave.
        assert!(!notice_warnings(&[], true));
        // The same piece drops back under the threshold right away: it still
        // counts as warning (the cooldown), so quiet.
        assert!(!notice_warnings(&["offhand".into()], true));
        // It stays away past the cooldown, then breaks again: play.
        assert!(!notice_warnings(&[], true));
        {
            let mut state = state().lock().unwrap();
            state.now_ms += WARNING_SOUND_COOLDOWN_MS + 1;
        }
        assert!(!notice_warnings(&[], true));
        assert!(notice_warnings(&["offhand".into()], true));
        // The setting off: never.
        assert!(!notice_warnings(&["armor:Feet".into()], false));
    }

    #[test]
    fn warning_bobbing_is_deterministic() {
        assert_eq!(bob_offset(0, 1234), 0.0);
        assert_eq!(bob_offset(2000, 0), 0.0);
        // Half a cycle: the zero crossing, within float noise.
        assert!(bob_offset(2000, 1000).abs() < 1e-3);
        let up = bob_offset(2000, 500);
        let down = bob_offset(2000, 1500);
        assert!(up > 0.0 && down < 0.0 && (up + down).abs() < 1e-3);
    }

    #[test]
    fn durability_text_lands_beside_the_vanilla_slots() {
        let mut s = settings();
        s.durability_display = DurabilityDisplay::Number;
        s.offhand_durability = true;
        let mut snap = snapshot();
        snap.offhand = Some(StackInfo {
            item: "minecraft:shield".into(),
            count: 1,
            damage: 300,
            max_damage: 336,
            glint: false,
        });
        let layout = hud_layout(&s, &snap);
        // A centered text under the off-hand slot's x center (left of the
        // hotbar), and none for the untouched main hand.
        assert!(!layout.hotbar_extras.is_empty());
        match &layout.hotbar_extras[0] {
            DrawCmd::Text { center_x, text, .. } => {
                assert_eq!(text, "36");
                let expected = 200.0 - 91.0 - 29.0 + 11.0;
                assert!((center_x.unwrap() - expected).abs() < 0.5);
            }
            other => panic!("expected text, got {other:?}"),
        }
    }

    #[test]
    fn top_anchor_with_push_reserves_a_corner() {
        let mut s = settings();
        s.anchor = Anchor::Top;
        s.side = Side::Right;
        let layout = hud_layout(&s, &snapshot());
        assert_eq!(layout.reserve_corner, Some((Anchor::Top, Side::Right)));
        // Without the push, no reservation.
        s.push_status_effect_icons = false;
        assert_eq!(hud_layout(&s, &snapshot()).reserve_corner, None);
        // The bossbar and subtitle pushes are recorded as asked-for.
        s.anchor = Anchor::TopCenter;
        s.push_status_effect_icons = true;
        assert!(hud_layout(&s, &snapshot()).bossbar_push > 0.0);
    }

    #[test]
    fn disabled_draws_nothing() {
        let mut s = settings();
        s.enabled = false;
        assert!(hud_layout(&s, &snapshot()).draws.is_empty());
    }

    #[test]
    fn reset_settings_restores_the_defaults() {
        state().lock().unwrap().runtime = ConfigRuntime::in_memory(&schema::SCHEMA);
        {
            let mut state = state().lock().unwrap();
            state.runtime.set(ids::OFFSET_X, ConfigValue::Int(25));
            state
                .runtime
                .set(ids::STYLE, ConfigValue::enum_name("NONE"));
            state.runtime.set(ids::SCALE, ConfigValue::Scale(1.5));
            state
                .runtime
                .set(ids::TEXT_COLOR, ConfigValue::enum_name("RED"));
        }
        reset_settings();
        let settings = {
            let state = state().lock().unwrap();
            settings_of(&state.runtime)
        };
        assert_eq!(settings.offset_x, 0);
        assert_eq!(settings.style, Style::Hotbar);
        assert_eq!(settings.scale, 1.0);
        assert_eq!(settings.text_color, TextColor::Auto);
        // A second reset is harmless.
        reset_settings();
    }

    #[test]
    fn the_mod_manager_entry_is_wellformed() {
        // The listing the `mods` hook pushes: id, `Name 1.0` title, a
        // description, and the menu key the game stores and rebinds.
        assert_eq!(MOD_ID, "tristanpbty_armor_hud");
        assert!(MOD_NAME.contains("Armor Hud"));
        assert!(MOD_VERSION.chars().all(|c| c.is_ascii_digit() || c == '.'));
        assert!(!MOD_DESCRIPTION.is_empty());
        assert_eq!(DEFAULT_MENU_KEY, "key.keyboard.h");
        assert_eq!(MENU_KEY_NAME, "menu");
    }

    #[test]
    fn slot_backgrounds_use_full_atlas_keys() {
        // Regression: `native_sprite` resolves names against the HUD atlas
        // directly, so a sprite must be named by its full key (the texture's
        // path under `textures/`), not by the short id Horizon's own
        // hud_layout uses. A short id draws nothing: the lookup misses.
        let layout = hud_layout(&settings(), &snapshot());
        let sprites: Vec<&String> = layout
            .draws
            .iter()
            .filter_map(|d| match d {
                DrawCmd::Sprite { name, .. } => Some(name),
                _ => None,
            })
            .collect();
        assert!(!sprites.is_empty(), "the slot background must draw");
        assert!(
            sprites
                .iter()
                .any(|n| n.as_str() == "gui/sprites/hud/hotbar"),
            "{:?}",
            sprites
        );
        for name in &sprites {
            assert!(name.starts_with("gui/sprites/"), "{name}");
        }
        // The empty-slot icons keep the same full-key form.
        let mut s = settings();
        s.widget_shown = WidgetShown::Always;
        let icons: Vec<String> = hud_layout(&s, &snapshot())
            .draws
            .iter()
            .filter_map(|d| match d {
                DrawCmd::Sprite { name, .. } => Some(name.clone()),
                _ => None,
            })
            .collect();
        assert!(
            icons
                .iter()
                .any(|n| n == "gui/sprites/container/slot/leggings"),
            "{:?}",
            icons
        );
    }

    #[test]
    fn scale_multiplies_the_geometry() {
        let mut s = settings();
        s.scale = 2.0;
        let rect = widget_rect(&s, &snapshot(), 2);
        assert_eq!(rect.w, (22.0 + 20.0) * 2.0);
        assert_eq!(rect.h, 44.0);
    }

    #[test]
    fn the_configuration_screen_opens_cycles_and_closes() {
        // Storage stays in memory for tests: the screen API must not touch
        // the real filesystem.
        state().lock().unwrap().runtime = ConfigRuntime::in_memory(&schema::SCHEMA);
        open_screen();
        assert!(state().lock().unwrap().screen.is_some());

        // The panel, the tab bar and the settings buttons all draw; no
        // preview ever does.
        let draws = screen_draw([640.0, 480.0], [320.0, 240.0]);
        assert!(draws.iter().any(|d| matches!(d, DrawCmd::Fill { .. })));
        assert!(
            draws
                .iter()
                .any(|d| matches!(d, DrawCmd::Text { text, .. } if text == "Armor HUD: On"))
        );
        assert!(
            draws
                .iter()
                .any(|d| matches!(d, DrawCmd::Text { text, .. } if text == "Done"))
        );
        assert!(
            !draws
                .iter()
                .any(|d| matches!(d, DrawCmd::Text { text, .. } if text == "preview"))
        );

        // The header: the emblem item beside the mod's name — the screen's
        // only item.
        let items = draws
            .iter()
            .filter(|d| matches!(d, DrawCmd::Item { .. }))
            .count();
        assert_eq!(items, 1, "only the header emblem draws an item");
        assert!(
            draws
                .iter()
                .any(|d| matches!(d, DrawCmd::Text { text, .. } if text == MOD_NAME))
        );
        assert_eq!(MOD_LOGO_ITEM, "minecraft:turtle_helmet");

        // A click on the first setting's button cycles it, like every
        // other button on the screen.
        let first = {
            let state = state().lock().unwrap();
            state.screen.as_ref().unwrap().controls[0].rect()
        };
        assert!(screen_input(&InputEvent::Press {
            pos: first.center(),
            button: 0,
        }));
        assert!(!state().lock().unwrap().runtime.bool(ids::ENABLED));

        // Tab switching through the keyboard path.
        assert!(screen_input(&InputEvent::Key {
            name: "key.keyboard.tab",
            text: None,
        }));
        assert_eq!(state().lock().unwrap().screen.as_ref().unwrap().tab, 1);

        // A click on the first tab goes back.
        let panel = screen_panel([640.0, 480.0]);
        let bar = tab_bar_rect(panel);
        assert!(screen_input(&InputEvent::Press {
            pos: [bar.x + 5.0, bar.y + 5.0],
            button: 0,
        }));
        assert_eq!(state().lock().unwrap().screen.as_ref().unwrap().tab, 0);

        // The Done button asks the game to close the screen; the frame
        // hook's reconciliation then saves and clears the mod's side.
        let done = {
            let state = state().lock().unwrap();
            state.screen.as_ref().unwrap().done.rect()
        };
        assert!(screen_input(&InputEvent::Press {
            pos: done.center(),
            button: 0,
        }));
        assert!(screen_reconcile(true), "the game should be told to close");
        assert!(state().lock().unwrap().screen.is_none());

        // A screen the game closed by itself (Escape) is saved and cleared
        // — but only once the game has actually shown it.
        open_screen();
        assert!(!screen_reconcile(false), "still opening: keep it");
        assert!(state().lock().unwrap().screen.is_some());
        assert!(!screen_draw([640.0, 480.0], [0.0, 0.0]).is_empty());
        assert!(!screen_reconcile(false));
        assert!(state().lock().unwrap().screen.is_none());

        close_screen();
        assert!(state().lock().unwrap().screen.is_none());
        // With the screen closed nothing draws.
        assert!(screen_draw([640.0, 480.0], [320.0, 240.0]).is_empty());
    }

    #[test]
    fn settings_read_back_from_the_runtime() {
        let mut runtime = ConfigRuntime::in_memory(&schema::SCHEMA);
        runtime.set(ids::ANCHOR, ConfigValue::enum_name("TOP"));
        runtime.set(ids::SCALE, ConfigValue::Scale(1.5));
        runtime.set(ids::MIN_DURABILITY_PERCENTAGE, ConfigValue::Float(0.25));
        runtime.set(ids::TEXT_COLOR, ConfigValue::enum_name("AQUA"));
        let s = settings_of(&runtime);
        assert_eq!(s.anchor, Anchor::Top);
        assert_eq!(s.scale, 1.5);
        assert_eq!(s.min_durability_percentage, 0.25);
        assert_eq!(s.text_color, TextColor::Aqua);
        // Unknown names fall back to their defaults.
        runtime.set(ids::SIDE, ConfigValue::text("MIDDLE"));
        runtime.set(ids::TEXT_COLOR, ConfigValue::text("CHARTREUSE"));
        assert_eq!(settings_of(&runtime).side, Side::Left);
        assert_eq!(settings_of(&runtime).text_color, TextColor::Auto);
    }

    #[test]
    fn text_color_dresses_the_durability_numbers() {
        let mut s = settings();
        s.durability_display = DurabilityDisplay::Number;
        // Auto: vanilla's damage scale, green when pristine, red when not.
        let auto = hud_layout(&s, &snapshot());
        // Fixed: every durability text wears the chosen color, whatever
        // the damage — the armor row's and the off-hand's beside the hotbar.
        s.text_color = TextColor::Aqua;
        let mut snap = snapshot();
        snap.offhand = Some(StackInfo {
            item: "minecraft:shield".into(),
            count: 1,
            damage: 168,
            max_damage: 336,
            glint: false,
        });
        let aqua = hud_layout(&s, &snap);
        let colors = |layout: &HudLayout| {
            layout
                .draws
                .iter()
                .filter_map(|d| match d {
                    DrawCmd::Text { rgb, .. } => Some(*rgb),
                    _ => None,
                })
                .collect::<Vec<_>>()
        };
        let auto_colors = colors(&auto);
        let aqua_colors = colors(&aqua);
        assert_eq!(auto_colors.len(), 2);
        assert_eq!(aqua_colors.len(), 2);
        assert!(aqua_colors.iter().all(|c| *c == TextColor::Aqua.rgb(0.5)));
        assert_ne!(auto_colors, aqua_colors);
        match aqua.hotbar_extras.first() {
            Some(DrawCmd::Text { rgb, .. }) => assert_eq!(*rgb, 0xFF55_FFFF),
            other => panic!("expected the off-hand's text, got {other:?}"),
        }
    }
}
