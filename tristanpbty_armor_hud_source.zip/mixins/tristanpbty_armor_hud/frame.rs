// The frame clock: advances the mod's millisecond clock (the warning mark's
// bobbing), lets the configuration save itself once a change settles, and
// reconciles the configuration screen with the game's own screen state —
// the Done button's click closes it, and a screen the game closed by itself
// (the Escape key) is saved and cleared.
fn frame(game: &mut crate::game::Game<'_>, elapsed: Duration) {
    use crate::game::tristanpbty_armor_hud as armor_hud;
    armor_hud::frame(elapsed.as_millis() as u64);
    let shows = game
        .native_mod_screen()
        .is_some_and(|id| id == armor_hud::MOD_ID);
    if armor_hud::screen_reconcile(shows) {
        game.native_mod_screen_close(armor_hud::MOD_ID);
    }
}
