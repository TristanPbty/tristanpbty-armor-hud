// A scroll step on the configuration screen: sliders, dropdowns and number
// fields step by it.
fn screen_scroll(
    game: &crate::game::Game<'_>,
    screen: &NativeScreenView<'_>,
    scroll: [f64; 2],
    canceled: &mut bool,
) {
    if screen.id != "mod" || game.native_mod_screen() != Some("tristanpbty_armor_hud") {
        return;
    }
    let pos = game.native_cursor();
    let event = tristanpbty_armor_hud_lib::widgets::InputEvent::Scroll {
        pos,
        steps: [scroll[0] as f32, scroll[1] as f32],
    };
    if crate::game::tristanpbty_armor_hud::screen_input(&event) {
        *canceled = true;
    }
}
