// The buttons under the mod's keybinds on its Options > Mods page. The
// configuration screen cannot open over the Options screen itself (a mod
// screen only opens over the world), so the page offers the one thing that
// works from there: resetting every setting to its default.
fn settings(mod_id: &str, buttons: &mut Vec<String>) {
    use crate::game::tristanpbty_armor_hud::MOD_ID;
    if mod_id != MOD_ID {
        return;
    }
    buttons.push("Reset all settings to their defaults".to_string());
}
