// A typed character on the configuration screen, for the number fields.
fn screen_char(
    game: &crate::game::Game<'_>,
    screen: &NativeScreenView<'_>,
    c: char,
    canceled: &mut bool,
) {
    if screen.id != "mod" || game.native_mod_screen() != Some("tristanpbty_armor_hud") {
        return;
    }
    let event = tristanpbty_armor_hud_lib::widgets::InputEvent::Key {
        name: "",
        text: Some(c),
    };
    if crate::game::tristanpbty_armor_hud::screen_input(&event) {
        *canceled = true;
    }
}
