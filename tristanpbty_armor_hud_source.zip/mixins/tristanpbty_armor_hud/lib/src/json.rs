//! Minimal JSON reader/writer for mod configuration files.
//!
//! The library deliberately keeps a zero-dependency policy: a native mod's
//! bundle crate may only depend on registry crates that already sit in
//! Horizon's `Cargo.lock`, and staying on `std` alone keeps the library
//! portable to every future TristanPbty mod regardless of the game's
//! dependency set. The parser accepts the subset of JSON that configuration
//! files need (objects, arrays, strings, numbers, booleans, null) and keeps
//! everything else out, so a malformed file fails loudly instead of silently
//! producing wrong settings.

use std::collections::BTreeMap;
use std::fmt;

/// A parsed JSON value. Object keys stay sorted so that two runs of the same
/// settings always serialise to the same bytes.
#[derive(Clone, Debug, PartialEq)]
pub enum Json {
    Null,
    Bool(bool),
    /// Numbers are kept in their textual form so integers never drift through
    /// floating point on a save/load round trip.
    Number(String),
    String(String),
    Array(Vec<Json>),
    Object(BTreeMap<String, Json>),
}

impl Json {
    pub fn number(n: impl Into<String>) -> Json {
        Json::Number(n.into())
    }

    pub fn as_bool(&self) -> Option<bool> {
        match self {
            Json::Bool(b) => Some(*b),
            _ => None,
        }
    }

    pub fn as_i64(&self) -> Option<i64> {
        match self {
            Json::Number(n) => n.parse::<f64>().ok().map(|f| f as i64),
            _ => None,
        }
    }

    pub fn as_f64(&self) -> Option<f64> {
        match self {
            Json::Number(n) => n.parse::<f64>().ok(),
            _ => None,
        }
    }

    pub fn as_str(&self) -> Option<&str> {
        match self {
            Json::String(s) => Some(s),
            _ => None,
        }
    }

    pub fn as_object(&self) -> Option<&BTreeMap<String, Json>> {
        match self {
            Json::Object(m) => Some(m),
            _ => None,
        }
    }

    pub fn get(&self, key: &str) -> Option<&Json> {
        self.as_object().and_then(|m| m.get(key))
    }
}

impl fmt::Display for Json {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Json::Null => f.write_str("null"),
            Json::Bool(b) => write!(f, "{b}"),
            Json::Number(n) => f.write_str(n),
            Json::String(s) => write!(f, "{}", escape(s)),
            Json::Array(items) => {
                f.write_str("[")?;
                for (i, item) in items.iter().enumerate() {
                    if i > 0 {
                        f.write_str(",")?;
                    }
                    write!(f, "{item}")?;
                }
                f.write_str("]")
            }
            Json::Object(map) => {
                f.write_str("{")?;
                for (i, (key, value)) in map.iter().enumerate() {
                    if i > 0 {
                        f.write_str(",")?;
                    }
                    write!(f, "{}:{}", escape(key), value)?;
                }
                f.write_str("}")
            }
        }
    }
}

/// Serialises `json` as a readable document: one member per line, two-space
/// indentation. Deterministic for equal values because object keys are sorted.
pub fn to_pretty(json: &Json) -> String {
    let mut out = String::new();
    write_pretty(json, 0, &mut out);
    out
}

fn write_pretty(json: &Json, depth: usize, out: &mut String) {
    let pad = "  ".repeat(depth);
    let inner = "  ".repeat(depth + 1);
    match json {
        Json::Object(map) if !map.is_empty() => {
            out.push_str("{\n");
            for (i, (key, value)) in map.iter().enumerate() {
                if i > 0 {
                    out.push_str(",\n");
                }
                out.push_str(&inner);
                out.push_str(&escape(key));
                out.push_str(": ");
                write_pretty(value, depth + 1, out);
            }
            out.push('\n');
            out.push_str(&pad);
            out.push('}');
        }
        Json::Object(_) => out.push_str("{}"),
        Json::Array(items) if !items.is_empty() => {
            out.push_str("[\n");
            for (i, item) in items.iter().enumerate() {
                if i > 0 {
                    out.push_str(",\n");
                }
                out.push_str(&inner);
                write_pretty(item, depth + 1, out);
            }
            out.push('\n');
            out.push_str(&pad);
            out.push(']');
        }
        Json::Array(_) => out.push_str("[]"),
        other => out.push_str(&other.to_string()),
    }
}

/// Escapes a string as a JSON string literal (with the surrounding quotes).
pub fn escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
    out
}

/// A parse error with the byte offset where the problem was found.
#[derive(Clone, Debug, PartialEq)]
pub struct ParseError {
    pub offset: usize,
    pub message: String,
}

impl fmt::Display for ParseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "JSON error at byte {}: {}", self.offset, self.message)
    }
}

impl std::error::Error for ParseError {}

/// Parses a JSON document.
pub fn parse(text: &str) -> Result<Json, ParseError> {
    let mut parser = Parser {
        bytes: text.as_bytes(),
        pos: 0,
    };
    parser.skip_ws();
    let value = parser.value()?;
    parser.skip_ws();
    if parser.pos != parser.bytes.len() {
        return Err(parser.err("trailing characters after the document"));
    }
    Ok(value)
}

struct Parser<'a> {
    bytes: &'a [u8],
    pos: usize,
}

impl<'a> Parser<'a> {
    fn err(&self, message: &str) -> ParseError {
        ParseError {
            offset: self.pos,
            message: message.to_string(),
        }
    }

    fn peek(&self) -> Option<u8> {
        self.bytes.get(self.pos).copied()
    }

    fn skip_ws(&mut self) {
        while let Some(b) = self.peek() {
            if b == b' ' || b == b'\t' || b == b'\n' || b == b'\r' {
                self.pos += 1;
            } else {
                break;
            }
        }
    }

    fn eat(&mut self, b: u8, what: &str) -> Result<(), ParseError> {
        if self.peek() == Some(b) {
            self.pos += 1;
            Ok(())
        } else {
            Err(self.err(what))
        }
    }

    fn literal(&mut self, word: &str) -> Result<(), ParseError> {
        if self.bytes[self.pos..].starts_with(word.as_bytes()) {
            self.pos += word.len();
            Ok(())
        } else {
            Err(self.err(&format!("expected `{word}`")))
        }
    }

    fn value(&mut self) -> Result<Json, ParseError> {
        match self.peek() {
            Some(b'{') => self.object(),
            Some(b'[') => self.array(),
            Some(b'"') => Ok(Json::String(self.string()?)),
            Some(b't') => {
                self.literal("true")?;
                Ok(Json::Bool(true))
            }
            Some(b'f') => {
                self.literal("false")?;
                Ok(Json::Bool(false))
            }
            Some(b'n') => {
                self.literal("null")?;
                Ok(Json::Null)
            }
            Some(b'-') | Some(b'0'..=b'9') => self.number(),
            _ => Err(self.err("expected a JSON value")),
        }
    }

    fn object(&mut self) -> Result<Json, ParseError> {
        self.eat(b'{', "expected `{`")?;
        let mut map = BTreeMap::new();
        self.skip_ws();
        if self.peek() == Some(b'}') {
            self.pos += 1;
            return Ok(Json::Object(map));
        }
        loop {
            self.skip_ws();
            let key = self.string()?;
            self.skip_ws();
            self.eat(b':', "expected `:`")?;
            self.skip_ws();
            let value = self.value()?;
            map.insert(key, value);
            self.skip_ws();
            match self.peek() {
                Some(b',') => self.pos += 1,
                Some(b'}') => {
                    self.pos += 1;
                    return Ok(Json::Object(map));
                }
                _ => return Err(self.err("expected `,` or `}`")),
            }
        }
    }

    fn array(&mut self) -> Result<Json, ParseError> {
        self.eat(b'[', "expected `[`")?;
        let mut items = Vec::new();
        self.skip_ws();
        if self.peek() == Some(b']') {
            self.pos += 1;
            return Ok(Json::Array(items));
        }
        loop {
            self.skip_ws();
            items.push(self.value()?);
            self.skip_ws();
            match self.peek() {
                Some(b',') => self.pos += 1,
                Some(b']') => {
                    self.pos += 1;
                    return Ok(Json::Array(items));
                }
                _ => return Err(self.err("expected `,` or `]`")),
            }
        }
    }

    fn string(&mut self) -> Result<String, ParseError> {
        self.eat(b'"', "expected a string")?;
        let mut out = String::new();
        loop {
            let b = self.peek().ok_or_else(|| self.err("unterminated string"))?;
            self.pos += 1;
            match b {
                b'"' => return Ok(out),
                b'\\' => {
                    let e = self.peek().ok_or_else(|| self.err("unterminated escape"))?;
                    self.pos += 1;
                    match e {
                        b'"' => out.push('"'),
                        b'\\' => out.push('\\'),
                        b'/' => out.push('/'),
                        b'b' => out.push('\u{8}'),
                        b'f' => out.push('\u{c}'),
                        b'n' => out.push('\n'),
                        b'r' => out.push('\r'),
                        b't' => out.push('\t'),
                        b'u' => {
                            let hex = self
                                .bytes
                                .get(self.pos..self.pos + 4)
                                .ok_or_else(|| self.err("truncated \\u escape"))?;
                            let text = std::str::from_utf8(hex)
                                .map_err(|_| self.err("invalid \\u escape"))?;
                            let code = u32::from_str_radix(text, 16)
                                .map_err(|_| self.err("invalid \\u escape"))?;
                            self.pos += 4;
                            // Surrogate pairs are unnecessary for config text
                            // but accepted for robustness.
                            if (0xD800..0xDC00).contains(&code)
                                && self.bytes.get(self.pos) == Some(&b'\\')
                            {
                                self.pos += 2; // skip `\u`
                                let low = self
                                    .bytes
                                    .get(self.pos..self.pos + 4)
                                    .ok_or_else(|| self.err("truncated surrogate"))?;
                                let text = std::str::from_utf8(low)
                                    .map_err(|_| self.err("invalid surrogate"))?;
                                let low = u32::from_str_radix(text, 16)
                                    .map_err(|_| self.err("invalid surrogate"))?;
                                self.pos += 4;
                                let combined = 0x1_0000 + ((code - 0xD800) << 10) + (low - 0xDC00);
                                out.push(char::from_u32(combined).unwrap_or('\u{FFFD}'));
                            } else {
                                out.push(char::from_u32(code).unwrap_or('\u{FFFD}'));
                            }
                        }
                        _ => return Err(self.err("unknown escape")),
                    }
                }
                _ => {
                    // Collect the whole UTF-8 sequence.
                    let len = utf8_len(b);
                    let start = self.pos - 1;
                    let end = start + len;
                    let slice = self
                        .bytes
                        .get(start..end)
                        .ok_or_else(|| self.err("truncated UTF-8"))?;
                    out.push_str(
                        std::str::from_utf8(slice).map_err(|_| self.err("invalid UTF-8"))?,
                    );
                    self.pos = end;
                }
            }
        }
    }

    fn number(&mut self) -> Result<Json, ParseError> {
        let start = self.pos;
        if self.peek() == Some(b'-') {
            self.pos += 1;
        }
        while matches!(self.peek(), Some(b'0'..=b'9')) {
            self.pos += 1;
        }
        if self.peek() == Some(b'.') {
            self.pos += 1;
            while matches!(self.peek(), Some(b'0'..=b'9')) {
                self.pos += 1;
            }
        }
        if matches!(self.peek(), Some(b'e') | Some(b'E')) {
            self.pos += 1;
            if matches!(self.peek(), Some(b'+') | Some(b'-')) {
                self.pos += 1;
            }
            while matches!(self.peek(), Some(b'0'..=b'9')) {
                self.pos += 1;
            }
        }
        let text = std::str::from_utf8(&self.bytes[start..self.pos])
            .map_err(|_| self.err("invalid number"))?;
        if text.is_empty() || text == "-" {
            return Err(self.err("invalid number"));
        }
        // Validate by asking the standard library.
        if text.parse::<f64>().is_err() {
            return Err(self.err("invalid number"));
        }
        Ok(Json::Number(text.to_string()))
    }
}

fn utf8_len(first: u8) -> usize {
    match first {
        0x00..=0x7F => 1,
        0xC0..=0xDF => 2,
        0xE0..=0xEF => 3,
        _ => 4,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn round_trips_a_config_document() {
        let text = r#"{"version":1,"enabled":true,"offsetX":-3,"ratio":0.05,"name":"a\"b"}"#;
        let value = parse(text).expect("parses");
        assert_eq!(value.get("version").and_then(Json::as_i64), Some(1));
        assert_eq!(value.get("enabled").and_then(Json::as_bool), Some(true));
        assert_eq!(value.get("offsetX").and_then(Json::as_i64), Some(-3));
        assert_eq!(value.get("ratio").and_then(Json::as_f64), Some(0.05));
        assert_eq!(value.get("name").and_then(Json::as_str), Some("a\"b"));
        let printed = to_pretty(&value);
        let reparsed = parse(&printed).expect("re-parses");
        assert_eq!(value, reparsed);
    }

    #[test]
    fn rejects_broken_documents() {
        assert!(parse("{").is_err());
        assert!(parse("{\"a\":}").is_err());
        assert!(parse("[1,]").is_err());
        assert!(parse("12x").is_err());
        assert!(parse("\"\\q\"").is_err());
    }

    #[test]
    fn keeps_integer_text_stable() {
        let value = parse("{\"n\":42}").unwrap();
        assert_eq!(to_pretty(&value), "{\n  \"n\": 42\n}");
    }
}
