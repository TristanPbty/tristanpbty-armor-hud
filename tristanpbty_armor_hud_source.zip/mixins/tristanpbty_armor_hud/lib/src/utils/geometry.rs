//! Geometry helpers shared by the widget model and the HUD layout code.
//!
//! All coordinates are GUI pixels: floating point, origin at the top-left of
//! the screen, `x` growing right and `y` growing down, exactly as Horizon's
//! `HudBatch` measures them.

/// A rectangle in GUI pixels.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Rect {
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
}

impl Rect {
    pub fn new(x: f32, y: f32, w: f32, h: f32) -> Rect {
        Rect { x, y, w, h }
    }

    pub fn left(&self) -> f32 {
        self.x
    }

    pub fn right(&self) -> f32 {
        self.x + self.w
    }

    pub fn top(&self) -> f32 {
        self.y
    }

    pub fn bottom(&self) -> f32 {
        self.y + self.h
    }

    pub fn center(&self) -> [f32; 2] {
        [self.x + self.w / 2.0, self.y + self.h / 2.0]
    }

    pub fn contains(&self, p: [f32; 2]) -> bool {
        p[0] >= self.x && p[0] < self.right() && p[1] >= self.y && p[1] < self.bottom()
    }

    /// The rectangle grown by `px` on every side.
    pub fn inflate(&self, px: f32) -> Rect {
        Rect {
            x: self.x - px,
            y: self.y - px,
            w: self.w + px * 2.0,
            h: self.h + px * 2.0,
        }
    }

    /// The rectangle moved by `(dx, dy)`.
    pub fn translate(&self, dx: f32, dy: f32) -> Rect {
        Rect {
            x: self.x + dx,
            y: self.y + dy,
            ..*self
        }
    }
}

/// Clamps `v` to `[lo, hi]`.
pub fn clamp(v: f32, lo: f32, hi: f32) -> f32 {
    v.max(lo).min(hi)
}

/// Rounds half away from zero, matching the GUI's integer snap more closely
/// than `f32::round` on negative halves in every case that matters here.
pub fn round(v: f32) -> f32 {
    (v + 0.5).floor().max(v.ceil().min(v.floor() + 1.0))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rect_contains_and_translates() {
        let r = Rect::new(10.0, 20.0, 30.0, 40.0);
        assert!(r.contains([10.0, 20.0]));
        assert!(r.contains([39.9, 59.9]));
        assert!(!r.contains([40.0, 60.0]));
        assert!(!r.contains([9.9, 20.0]));
        let moved = r.translate(-10.0, -20.0);
        assert_eq!(moved, Rect::new(0.0, 0.0, 30.0, 40.0));
    }

    #[test]
    fn clamp_works() {
        assert_eq!(clamp(5.0, 0.0, 3.0), 3.0);
        assert_eq!(clamp(-1.0, 0.0, 3.0), 0.0);
        assert_eq!(clamp(2.0, 0.0, 3.0), 2.0);
    }
}
