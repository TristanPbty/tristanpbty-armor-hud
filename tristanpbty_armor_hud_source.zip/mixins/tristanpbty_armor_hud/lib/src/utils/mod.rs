//! Small shared utilities: geometry, colors and the anchor vocabulary.

pub mod anchors;
pub mod color;
pub mod geometry;

pub use anchors::{Anchor, Orientation, Side};
pub use color::{WHITE, argb, channels, durability_color, rgb, with_alpha};
pub use geometry::{Rect, clamp, round};
