//! Loading and saving configuration files.
//!
//! The file layout is one JSON object per mod in the game's shared `config/`
//! folder, exactly where Fabric and NeoForge mods keep theirs, so a player
//! looking for `config/tristanpbty_armor_hud.json` finds what they expect.
//! Writes are atomic (a temporary file renamed over the target) and keep a
//! `.bak` of the previous good file, so a crash mid-save cannot destroy the
//! settings.
//!
//! The filesystem itself is behind a tiny trait so the logic is testable in
//! memory; the game side plugs [`FsDisk`] in.

use crate::config::schema::ConfigSchema;
use crate::config::validation::{Problem, check_range, coerce};
use crate::config::value::ConfigValue;
use crate::json::{self, Json};
use std::collections::BTreeMap;
use std::fmt;
use std::path::{Path, PathBuf};
use std::sync::Mutex;

/// What the storage layer can do.
pub trait Disk: Send {
    fn read(&self, path: &Path) -> Option<String>;
    fn write(&self, path: &Path, bytes: &[u8]) -> std::io::Result<()>;
    fn rename(&self, from: &Path, to: &Path) -> std::io::Result<()>;
    fn exists(&self, path: &Path) -> bool;
}

/// The real filesystem.
#[derive(Default)]
pub struct FsDisk;

impl Disk for FsDisk {
    fn read(&self, path: &Path) -> Option<String> {
        std::fs::read_to_string(path).ok()
    }

    fn write(&self, path: &Path, bytes: &[u8]) -> std::io::Result<()> {
        if let Some(dir) = path.parent() {
            std::fs::create_dir_all(dir)?;
        }
        std::fs::write(path, bytes)
    }

    fn rename(&self, from: &Path, to: &Path) -> std::io::Result<()> {
        std::fs::rename(from, to)
    }

    fn exists(&self, path: &Path) -> bool {
        path.exists()
    }
}

/// An in-memory disk for tests: path -> bytes. Clones share the same files,
/// so a test can keep one handle to verify what was written through the
/// other.
#[derive(Clone, Default)]
pub struct MemoryDisk {
    files: std::sync::Arc<Mutex<BTreeMap<PathBuf, Vec<u8>>>>,
}

impl Disk for MemoryDisk {
    fn read(&self, path: &Path) -> Option<String> {
        let files = self.files.lock().unwrap();
        files
            .get(path)
            .and_then(|b| String::from_utf8(b.clone()).ok())
    }

    fn write(&self, path: &Path, bytes: &[u8]) -> std::io::Result<()> {
        if let Some(dir) = path.parent() {
            let _ = dir;
        }
        self.files
            .lock()
            .unwrap()
            .insert(path.to_path_buf(), bytes.to_vec());
        Ok(())
    }

    fn rename(&self, from: &Path, to: &Path) -> std::io::Result<()> {
        let mut files = self.files.lock().unwrap();
        match files.remove(from) {
            Some(bytes) => {
                files.insert(to.to_path_buf(), bytes);
                Ok(())
            }
            None => Err(std::io::Error::new(
                std::io::ErrorKind::NotFound,
                "no such file",
            )),
        }
    }

    fn exists(&self, path: &Path) -> bool {
        self.files.lock().unwrap().contains_key(path)
    }
}

/// The outcome of a load.
#[derive(Clone, Debug, Default)]
pub struct Loaded {
    /// The validated values, keyed by entry id.
    pub values: BTreeMap<String, ConfigValue>,
    /// What was ignored, for the log.
    pub problems: Vec<Problem>,
    /// The migration notes that applied, for the log.
    pub migrations: Vec<&'static str>,
    /// True when the file did not exist and everything is a default.
    pub fresh: bool,
}

/// Where a load went irrecoverably wrong.
#[derive(Clone, Debug)]
pub enum LoadError {
    /// The file exists but is not valid JSON.
    Parse { path: String, cause: String },
    /// The document is not a JSON object.
    NotAnObject { path: String },
    /// The migrations cannot bring the file to this version.
    Migration { path: String, cause: String },
}

impl fmt::Display for LoadError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            LoadError::Parse { path, cause } => write!(f, "{path}: {cause}"),
            LoadError::NotAnObject { path } => write!(f, "{path}: expected a JSON object"),
            LoadError::Migration { path, cause } => write!(f, "{path}: {cause}"),
        }
    }
}

impl std::error::Error for LoadError {}

impl LoadError {
    /// The file the error is about.
    pub fn path(&self) -> &str {
        match self {
            LoadError::Parse { path, .. }
            | LoadError::NotAnObject { path }
            | LoadError::Migration { path, .. } => path,
        }
    }

    /// The human-readable reason.
    pub fn cause(&self) -> String {
        match self {
            LoadError::Parse { cause, .. } => cause.clone(),
            LoadError::NotAnObject { .. } => "expected a JSON object".to_string(),
            LoadError::Migration { cause, .. } => cause.clone(),
        }
    }
}

/// The path of a mod's file inside `config_dir`.
pub fn config_path(config_dir: &Path, mod_id: &str) -> PathBuf {
    config_dir.join(format!("{mod_id}.json"))
}

/// Loads, migrates and validates the file at `path` against `schema`,
/// applying `migrations` when the file's version is older than the schema's.
///
/// Missing keys take their defaults; values that fail validation are dropped
/// for their defaults and reported. A file that cannot be parsed at all is
/// an error, and the caller decides whether to fall back to defaults.
pub fn load(
    disk: &dyn Disk,
    path: &Path,
    schema: &ConfigSchema,
    migrations: &[crate::config::migration::Migration],
) -> Result<Loaded, LoadError> {
    let file = path.to_string_lossy().to_string();
    let Some(text) = disk.read(path) else {
        return Ok(Loaded {
            values: default_values(schema),
            problems: Vec::new(),
            migrations: Vec::new(),
            fresh: true,
        });
    };
    let parsed = json::parse(&text).map_err(|cause| LoadError::Parse {
        path: file.clone(),
        cause: cause.to_string(),
    })?;
    let mut map = match parsed {
        Json::Object(m) => m,
        _ => {
            return Err(LoadError::NotAnObject { path: file });
        }
    };
    let version = crate::config::migration::version_of(&map);
    let migrations =
        crate::config::migration::migrate(&mut map, version, schema.version, migrations).map_err(
            |cause| LoadError::Migration {
                path: file.clone(),
                cause: cause.to_string(),
            },
        )?;

    let mut loaded = Loaded {
        values: default_values(schema),
        problems: Vec::new(),
        migrations,
        fresh: false,
    };
    let known: Vec<&str> = schema.entries().map(|e| e.id).collect();
    for (key, value) in &map {
        if key == "version" {
            continue;
        }
        if let Some(entry) = schema.entry(key) {
            match coerce(entry, value).and_then(|v| check_range(entry, &v).map(|()| v)) {
                Ok(v) => {
                    loaded.values.insert(key.clone(), v);
                }
                Err(problem) => {
                    loaded.problems.push(problem);
                }
            }
        } else if !known.contains(&key.as_str()) {
            loaded.problems.push(Problem::UnknownKey(key.clone()));
        }
    }
    Ok(loaded)
}

/// Saves `values` under `schema` to `path`, atomically, keeping a backup.
pub fn save(
    disk: &dyn Disk,
    path: &Path,
    schema: &ConfigSchema,
    values: &BTreeMap<String, ConfigValue>,
) -> std::io::Result<()> {
    let mut map = BTreeMap::new();
    map.insert(
        "version".to_string(),
        Json::number(schema.version.to_string()),
    );
    for entry in schema.entries() {
        if let Some(value) = values.get(entry.id) {
            map.insert(entry.id.to_string(), to_json(value));
        }
    }
    let text = json::to_pretty(&Json::Object(map));
    let temp = path.with_extension("json.tmp");
    disk.write(&temp, text.as_bytes())?;
    if disk.exists(path) {
        let backup = path.with_extension("json.bak");
        let _ = disk.rename(path, &backup);
    }
    disk.rename(&temp, path)
}

/// Serialises a typed value.
pub fn to_json(value: &ConfigValue) -> Json {
    match value {
        ConfigValue::Bool(b) => Json::Bool(*b),
        ConfigValue::Int(i) => Json::number(i.to_string()),
        ConfigValue::Float(f) => Json::number(crate::config::value::format_float(*f)),
        ConfigValue::Str(s) | ConfigValue::Enum(s) | ConfigValue::Keybind(s) => {
            Json::String(s.to_string())
        }
        ConfigValue::Color(c) => Json::String(format!("#{:06X}", c & 0x00FF_FFFF)),
        ConfigValue::Position(x, y) => Json::Array(vec![
            Json::number(x.to_string()),
            Json::number(y.to_string()),
        ]),
        ConfigValue::Scale(s) => Json::number(crate::config::value::format_float(*s as f64)),
    }
}

/// Every entry at its default.
pub fn default_values(schema: &ConfigSchema) -> BTreeMap<String, ConfigValue> {
    schema
        .entries()
        .map(|e| (e.id.to_string(), e.default.clone()))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::schema::{ConfigEntry, ConfigTab};

    fn schema() -> ConfigSchema {
        const ENTRIES: &[ConfigEntry] = &[
            ConfigEntry::bool("enabled", "Enabled", "help", true),
            ConfigEntry::int("offsetX", "X", "help", 0, -50, 50),
            ConfigEntry::enumeration("side", "Side", "help", &["LEFT", "RIGHT"], "LEFT"),
            ConfigEntry::scale("scale", "Scale", "help", 1.0, 0.5, 2.0),
        ];
        const TABS: &[ConfigTab] = &[ConfigTab {
            id: "general",
            label: "General",
            entries: ENTRIES,
        }];
        ConfigSchema {
            mod_id: "test_mod",
            version: 1,
            tabs: TABS,
        }
    }

    #[test]
    fn round_trips_through_the_disk() {
        let disk = MemoryDisk::default();
        let path = Path::new("/config/test_mod.json");
        let s = schema();
        let loaded = load(&disk, path, &s, &[]).unwrap();
        assert!(loaded.fresh);
        assert_eq!(loaded.values["enabled"], ConfigValue::Bool(true));

        let mut values = loaded.values.clone();
        values.insert("offsetX".into(), ConfigValue::Int(-12));
        values.insert("side".into(), ConfigValue::Enum("RIGHT".into()));
        save(&disk, path, &s, &values).unwrap();

        let reloaded = load(&disk, path, &s, &[]).unwrap();
        assert!(!reloaded.fresh);
        assert!(reloaded.problems.is_empty());
        assert_eq!(reloaded.values["offsetX"], ConfigValue::Int(-12));
        assert_eq!(reloaded.values["side"], ConfigValue::Enum("RIGHT".into()));
        assert_eq!(reloaded.values["scale"], ConfigValue::Scale(1.0));
    }

    #[test]
    fn keeps_a_backup_of_the_previous_file() {
        let disk = MemoryDisk::default();
        let path = Path::new("/config/test_mod.json");
        let s = schema();
        let values = default_values(&s);
        save(&disk, path, &s, &values).unwrap();
        let mut changed = values.clone();
        changed.insert("enabled".into(), ConfigValue::Bool(false));
        save(&disk, path, &s, &changed).unwrap();
        assert!(disk.exists(Path::new("/config/test_mod.json.bak")));
        let reloaded = load(&disk, path, &s, &[]).unwrap();
        assert_eq!(reloaded.values["enabled"], ConfigValue::Bool(false));
    }

    #[test]
    fn reports_invalid_values_and_uses_defaults() {
        let disk = MemoryDisk::default();
        let path = Path::new("/config/test_mod.json");
        disk.write(
            path,
            b"{\"offsetX\": 999, \"side\": \"MIDDLE\", \"who\": 1}",
        )
        .unwrap();
        let s = schema();
        let loaded = load(&disk, path, &s, &[]).unwrap();
        assert_eq!(loaded.problems.len(), 3);
        assert_eq!(loaded.values["offsetX"], ConfigValue::Int(0));
        assert_eq!(loaded.values["side"], ConfigValue::Enum("LEFT".into()));
    }

    #[test]
    fn unparseable_file_is_an_error() {
        let disk = MemoryDisk::default();
        let path = Path::new("/config/test_mod.json");
        disk.write(path, b"{nope").unwrap();
        assert!(matches!(
            load(&disk, path, &schema(), &[]),
            Err(LoadError::Parse { .. })
        ));
    }
}
