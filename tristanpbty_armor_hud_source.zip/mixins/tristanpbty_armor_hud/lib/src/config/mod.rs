//! The configuration system: schema, values, validation, migrations,
//! persistence and the runtime.
//!
//! A mod describes its settings once, as a [`schema::ConfigSchema`], and gets
//! the rest for free:
//!
//! ```ignore
//! static SCHEMA: ConfigSchema = ConfigSchema { mod_id: "my_mod", version: 1, tabs: TABS };
//! let runtime = ConfigRuntime::with_storage(
//!     &SCHEMA, Box::new(FsDisk), config_dir.join("my_mod.json"), &[],
//! );
//! ```
//!
//! The host calls [`runtime::ConfigRuntime::tick`] from its frame hook; the
//! store saves itself at most once per debounce window after a change.

pub mod migration;
pub mod persistence;
pub mod runtime;
pub mod schema;
pub mod validation;
pub mod value;

pub use migration::{Migration, MigrationError, migrate, version_of};
pub use persistence::{Disk, FsDisk, LoadError, Loaded, MemoryDisk, config_path};
pub use runtime::{Change, ConfigRuntime, now_ms};
pub use schema::{ConfigEntry, ConfigSchema, ConfigTab, Limits};
pub use validation::{Problem, check_range, coerce};
pub use value::{ConfigValue, format_float, keybind_label, parse_color};
