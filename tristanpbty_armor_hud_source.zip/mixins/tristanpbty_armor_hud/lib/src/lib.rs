//! Tristan's Lib (`tristanpbty_lib`): the shared foundation for TristanPbty's
//! native Horizon mods.
//!
//! The crate is pure Rust on the standard library only. A Horizon native mod
//! is a source bundle the launcher compiles inside its own workspace, and the
//! bundle's crates may only use registry dependencies that already exist in
//! Horizon's `Cargo.lock`; a zero-dependency library therefore stays usable
//! by every future mod regardless of the game's own dependency set, and its
//! logic stays testable outside the game.
//!
//! Three groups of tools live here:
//!
//! * [`config`] — a declarative configuration system with defaults, ranges,
//!   validation, versioned migrations, atomic persistence and debounced
//!   runtime updates.
//! * [`widgets`] — the model of the configuration screen controls (toggle,
//!   slider, dropdown, button, number input, color picker, keybind, position
//!   editor, scale selector). Widgets are host-independent: they consume
//!   abstract input events and produce an abstract draw list, so the same
//!   code runs in unit tests and against Horizon's GUI helpers.
//! * [`minecraft`] and [`utils`] — the value types mods share: equipment
//!   snapshots and durability math, colors, rectangles and the anchor
//!   vocabulary.

pub mod config;
pub mod json;
pub mod minecraft;
pub mod utils;
pub mod widgets;

/// The library's semver version, reported in diagnostics.
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// The identity of a mod built on this library, used in log lines.
pub fn log_prefix(mod_id: &str) -> String {
    format!("[{mod_id}]")
}

#[cfg(test)]
mod tests {
    #[test]
    fn version_is_reported() {
        assert!(!super::VERSION.is_empty());
    }
}
