//! The number input: a small text field that parses into an integer or
//! float entry, with the arrows of the focused field stepping the value.

use super::{
    ACCENT, DrawCmd, InputEvent, InputResult, PANEL, PANEL_HOVER, TEXT, TEXT_DIM, Widget,
    draw_border, draw_label,
};
use crate::config::runtime::ConfigRuntime;
use crate::config::value::ConfigValue;
use crate::json::Json;
use crate::utils::Rect;

pub struct NumberInput {
    key: String,
    rect: Rect,
    /// The text being edited; `None` when the field shows the stored value.
    buffer: Option<String>,
}

/// Clamps an `f64` to `[lo, hi]` (the geometry helper is `f32`).
fn clamp64(v: f64, lo: f64, hi: f64) -> f64 {
    v.max(lo).min(hi)
}

impl NumberInput {
    pub fn new(key: &str, rect: Rect) -> NumberInput {
        NumberInput {
            key: key.to_string(),
            rect,
            buffer: None,
        }
    }

    fn shown(&self, runtime: &ConfigRuntime) -> String {
        match &self.buffer {
            Some(text) => text.clone(),
            None => runtime
                .get(&self.key)
                .and_then(ConfigValue::as_f64)
                .map(crate::config::value::format_float)
                .unwrap_or_default(),
        }
    }

    fn step(&mut self, runtime: &mut ConfigRuntime, up: bool, fine: bool) -> bool {
        let entry = runtime.schema().entry(&self.key);
        let (lo, hi, step) = match entry.map(|e| e.limits.clone()) {
            Some(crate::config::schema::Limits::Float(lo, hi, step)) => (lo, hi, step),
            Some(crate::config::schema::Limits::Int(lo, hi)) => (lo as f64, hi as f64, 1.0),
            Some(crate::config::schema::Limits::Scale(lo, hi)) => (lo as f64, hi as f64, 0.05),
            _ => (0.0, 100.0, 1.0),
        };
        let step = if fine { step / 10.0 } else { step };
        let current = runtime
            .get(&self.key)
            .and_then(ConfigValue::as_f64)
            .unwrap_or(lo);
        let next = clamp64(current + if up { step } else { -step }, lo, hi);
        let typed = match runtime.get(&self.key) {
            Some(ConfigValue::Int(_)) => ConfigValue::Int(next as i64),
            Some(ConfigValue::Scale(_)) => ConfigValue::Scale(next as f32),
            _ => ConfigValue::Float(next),
        };
        runtime.set(&self.key, typed)
    }
}

impl Widget for NumberInput {
    fn key(&self) -> &str {
        &self.key
    }

    fn rect(&self) -> Rect {
        self.rect
    }

    fn draw(&self, out: &mut Vec<DrawCmd>, focused: bool, runtime: &ConfigRuntime) {
        out.push(DrawCmd::Fill {
            rect: [self.rect.x, self.rect.y, self.rect.w, self.rect.h],
            argb: if self.buffer.is_some() || focused {
                PANEL_HOVER
            } else {
                PANEL
            },
        });
        draw_border(
            out,
            self.rect,
            if self.buffer.is_some() {
                ACCENT
            } else {
                super::BORDER
            },
        );
        draw_label(
            out,
            &self.shown(runtime),
            [self.rect.x + 5.0, self.rect.y + 5.0],
            TEXT,
        );
        // The little up/down arrows on the right.
        let ax = self.rect.right() - 10.0;
        let cy = self.rect.y + self.rect.h / 2.0;
        for (i, dy) in [-1.0_f32, 0.0, 1.0].iter().enumerate() {
            let w = if i == 1 { 5.0 } else { 2.0 };
            out.push(DrawCmd::Fill {
                rect: [ax - w / 2.0, cy - 3.0 + dy, w, 1.0],
                argb: TEXT_DIM,
            });
            out.push(DrawCmd::Fill {
                rect: [ax - w / 2.0, cy + 3.0 - dy, w, 1.0],
                argb: TEXT_DIM,
            });
        }
    }

    fn input(&mut self, event: &InputEvent<'_>, runtime: &mut ConfigRuntime) -> InputResult {
        match event {
            InputEvent::Press { pos, button: 0 } if self.rect.contains(*pos) => {
                // Clicking the arrows steps; clicking the middle focuses.
                let near_arrows = pos[0] > self.rect.right() - 16.0;
                if near_arrows {
                    let up = pos[1] < self.rect.y + self.rect.h / 2.0;
                    return InputResult::changed_if(self.step(runtime, up, false));
                }
                if self.buffer.is_none() {
                    self.buffer = Some(self.shown(runtime));
                }
                InputResult::consumed()
            }
            InputEvent::Key { name, text } if self.buffer.is_some() => match *name {
                "key.keyboard.enter" | "key.keyboard.escape" | "key.keyboard.tab" => {
                    let buffer = self.buffer.take().unwrap_or_default();
                    if name == &"key.keyboard.escape" {
                        return InputResult::consumed();
                    }
                    let json = Json::number(buffer);
                    InputResult::changed_if(runtime.set_from_json(&self.key, &json))
                }
                "key.keyboard.backspace" => {
                    if let Some(text) = self.buffer.as_mut() {
                        text.pop();
                    }
                    InputResult::consumed()
                }
                _ => {
                    if let Some(c) = text
                        && (c.is_ascii_digit() || *c == '-' || *c == '.' || *c == ',')
                        && let Some(t) = self.buffer.as_mut()
                    {
                        t.push(if *c == ',' { '.' } else { *c })
                    }
                    InputResult::consumed()
                }
            },
            InputEvent::Scroll { pos, steps } if self.rect.contains(*pos) => {
                InputResult::changed_if(self.step(runtime, steps[1] < 0.0, true))
            }
            _ => InputResult::ignored(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};

    const ENTRIES: &[ConfigEntry] = &[ConfigEntry::int(
        "minDurabilityValue",
        "Minimum",
        "help",
        20,
        0,
        500,
    )];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "warnings",
        label: "Warnings",
        entries: ENTRIES,
    }];
    static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: "test_mod",
        version: 1,
        tabs: TABS,
    };

    #[test]
    fn typing_and_entering_a_value() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut field = NumberInput::new("minDurabilityValue", Rect::new(0.0, 0.0, 60.0, 18.0));
        // Focus the field.
        field.input(
            &InputEvent::Press {
                pos: [20.0, 9.0],
                button: 0,
            },
            &mut runtime,
        );
        // Clear and type 7.
        for _ in 0..2 {
            field.input(
                &InputEvent::Key {
                    name: "key.keyboard.backspace",
                    text: None,
                },
                &mut runtime,
            );
        }
        {
            let c = '7';
            field.input(
                &InputEvent::Key {
                    name: "key.keyboard.digit7",
                    text: Some(c),
                },
                &mut runtime,
            );
        }
        field.input(
            &InputEvent::Key {
                name: "key.keyboard.enter",
                text: None,
            },
            &mut runtime,
        );
        assert_eq!(runtime.int("minDurabilityValue"), 7);
    }

    #[test]
    fn arrows_and_scroll_step_within_limits() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut field = NumberInput::new("minDurabilityValue", Rect::new(0.0, 0.0, 60.0, 18.0));
        field.input(
            &InputEvent::Press {
                pos: [55.0, 4.0],
                button: 0,
            },
            &mut runtime,
        );
        assert_eq!(runtime.int("minDurabilityValue"), 21);
        field.input(
            &InputEvent::Scroll {
                pos: [30.0, 9.0],
                steps: [0.0, 2.0],
            },
            &mut runtime,
        );
        assert_eq!(runtime.int("minDurabilityValue"), 20);
    }

    #[test]
    fn escape_discards_the_buffer() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut field = NumberInput::new("minDurabilityValue", Rect::new(0.0, 0.0, 60.0, 18.0));
        field.input(
            &InputEvent::Press {
                pos: [20.0, 9.0],
                button: 0,
            },
            &mut runtime,
        );
        field.input(
            &InputEvent::Key {
                name: "key.keyboard.digit1",
                text: Some('1'),
            },
            &mut runtime,
        );
        field.input(
            &InputEvent::Key {
                name: "key.keyboard.escape",
                text: None,
            },
            &mut runtime,
        );
        assert_eq!(runtime.int("minDurabilityValue"), 20);
    }
}
