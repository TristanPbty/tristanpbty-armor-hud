//! The dropdown: a closed-list selector for enum entries, opening a list on
//! click and closing on a choice or an outside click.

use super::{
    ACCENT, DrawCmd, InputEvent, InputResult, PANEL, PANEL_HOVER, TEXT, TEXT_DIM, Widget,
    draw_border, draw_label,
};
use crate::config::runtime::ConfigRuntime;
use crate::config::value::ConfigValue;
use crate::utils::Rect;

pub struct Dropdown {
    key: String,
    rect: Rect,
    open: bool,
    hover: Option<usize>,
}

/// The row height of the open list.
pub const ROW: f32 = 14.0;

impl Dropdown {
    pub fn new(key: &str, rect: Rect) -> Dropdown {
        Dropdown {
            key: key.to_string(),
            rect,
            open: false,
            hover: None,
        }
    }

    fn variants(&self, runtime: &ConfigRuntime) -> Vec<&'static str> {
        runtime
            .schema()
            .entry(&self.key)
            .and_then(|e| e.limits.variants())
            .map(|v| v.to_vec())
            .unwrap_or_default()
    }

    fn list_rect(&self, count: usize) -> Rect {
        Rect::new(
            self.rect.x,
            self.rect.bottom() + 1.0,
            self.rect.w,
            ROW * count as f32 + 2.0,
        )
    }
}

impl Widget for Dropdown {
    fn key(&self) -> &str {
        &self.key
    }

    fn rect(&self) -> Rect {
        self.rect
    }

    fn draw(&self, out: &mut Vec<DrawCmd>, focused: bool, runtime: &ConfigRuntime) {
        let variants = self.variants(runtime);
        let current = runtime.text(&self.key).to_string();
        out.push(DrawCmd::Fill {
            rect: [self.rect.x, self.rect.y, self.rect.w, self.rect.h],
            argb: if focused && !self.open {
                PANEL_HOVER
            } else {
                PANEL
            },
        });
        draw_border(out, self.rect, super::BORDER);
        draw_label(out, &current, [self.rect.x + 6.0, self.rect.y + 5.0], TEXT);
        // The little triangle.
        let cx = self.rect.right() - 8.0;
        let cy = self.rect.y + self.rect.h / 2.0;
        let (dir, spread) = if self.open { (1.0, 2.0) } else { (-1.0, -2.0) };
        for dy in 0..3 {
            let w = 6.0 - dy as f32 * 2.0;
            out.push(DrawCmd::Fill {
                rect: [cx - w / 2.0, cy + dir * (dy as f32 - 1.0), w, 1.0],
                argb: TEXT_DIM,
            });
        }
        let _ = spread;
        if self.open {
            let list = self.list_rect(variants.len());
            out.push(DrawCmd::Fill {
                rect: [list.x, list.y, list.w, list.h],
                argb: PANEL,
            });
            draw_border(out, list, super::BORDER);
            for (i, name) in variants.iter().enumerate() {
                if Some(i) == self.hover || *name == current {
                    out.push(DrawCmd::Fill {
                        rect: [
                            list.x + 1.0,
                            list.y + 1.0 + i as f32 * ROW,
                            list.w - 2.0,
                            ROW,
                        ],
                        argb: if *name == current {
                            ACCENT
                        } else {
                            PANEL_HOVER
                        },
                    });
                }
                draw_label(
                    out,
                    name,
                    [list.x + 6.0, list.y + 3.0 + i as f32 * ROW],
                    TEXT,
                );
            }
        }
    }

    fn input(&mut self, event: &InputEvent<'_>, runtime: &mut ConfigRuntime) -> InputResult {
        let variants = self.variants(runtime);
        match event {
            InputEvent::Press { pos, button: 0 } => {
                if self.open {
                    let list = self.list_rect(variants.len());
                    if list.contains(*pos) {
                        let row = ((pos[1] - list.y - 1.0) / ROW) as usize;
                        if row < variants.len() {
                            let name = variants[row].to_string();
                            self.open = false;
                            return InputResult::changed_if(
                                runtime.set(
                                    &self.key,
                                    ConfigValue::Enum(std::borrow::Cow::Owned(name)),
                                ),
                            );
                        }
                    }
                    self.open = false;
                    InputResult::consumed()
                } else if self.rect.contains(*pos) {
                    self.open = true;
                    InputResult::consumed()
                } else {
                    InputResult::ignored()
                }
            }
            InputEvent::Drag { pos, .. } if self.open => {
                let list = self.list_rect(variants.len());
                self.hover = if list.contains(*pos) {
                    Some(((pos[1] - list.y - 1.0) / ROW) as usize)
                } else {
                    None
                };
                InputResult::consumed()
            }
            InputEvent::Scroll { pos, steps } if self.rect.contains(*pos) && !self.open => {
                // Scrolling cycles the choice, like vanilla's cycling buttons.
                if variants.is_empty() {
                    return InputResult::ignored();
                }
                let current = runtime.text(&self.key).to_string();
                let at = variants.iter().position(|v| *v == current).unwrap_or(0);
                let len = variants.len() as i32;
                let next = (at as i32 - steps[1] as i32).rem_euclid(len) as usize;
                InputResult::changed_if(runtime.set(
                    &self.key,
                    ConfigValue::Enum(std::borrow::Cow::Borrowed(variants[next])),
                ))
            }
            _ => InputResult::ignored(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};

    const VARIANTS: &[&str] = &["ALWAYS", "IF_ANY_PRESENT", "NOT_EMPTY"];
    const ENTRIES: &[ConfigEntry] = &[ConfigEntry::enumeration(
        "widgetShown",
        "Shown",
        "help",
        VARIANTS,
        "NOT_EMPTY",
    )];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "display",
        label: "Display",
        entries: ENTRIES,
    }];
    static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: "test_mod",
        version: 1,
        tabs: TABS,
    };

    #[test]
    fn opens_and_selects() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut dd = Dropdown::new("widgetShown", Rect::new(0.0, 0.0, 120.0, 18.0));
        let open = InputEvent::Press {
            pos: [60.0, 9.0],
            button: 0,
        };
        assert!(dd.input(&open, &mut runtime).consumed);
        // The list sits below the button; pick the first row.
        let pick = InputEvent::Press {
            pos: [60.0, 22.0],
            button: 0,
        };
        assert!(dd.input(&pick, &mut runtime).changed);
        assert_eq!(runtime.text("widgetShown"), "ALWAYS");
    }

    #[test]
    fn scrolling_cycles() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut dd = Dropdown::new("widgetShown", Rect::new(0.0, 0.0, 120.0, 18.0));
        dd.input(
            &InputEvent::Scroll {
                pos: [60.0, 9.0],
                steps: [0.0, 1.0],
            },
            &mut runtime,
        );
        assert_eq!(runtime.text("widgetShown"), "IF_ANY_PRESENT");
        dd.input(
            &InputEvent::Scroll {
                pos: [60.0, 9.0],
                steps: [0.0, 1.0],
            },
            &mut runtime,
        );
        dd.input(
            &InputEvent::Scroll {
                pos: [60.0, 9.0],
                steps: [0.0, 1.0],
            },
            &mut runtime,
        );
        // Wrapped around the three variants: ALWAYS -> NOT_EMPTY.
        assert_eq!(runtime.text("widgetShown"), "NOT_EMPTY");
    }
}
