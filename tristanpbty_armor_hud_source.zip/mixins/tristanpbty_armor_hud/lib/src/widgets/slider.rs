//! The slider: a draggable track for integer and float entries.

use super::{
    ACCENT, DrawCmd, InputEvent, InputResult, PANEL, PANEL_HOVER, TEXT, TEXT_DIM, TRACK, Widget,
    draw_border, draw_label,
};
use crate::config::runtime::ConfigRuntime;
use crate::config::schema::Limits;
use crate::config::value::{ConfigValue, format_float};
use crate::utils::{Rect, clamp};

pub struct Slider {
    key: String,
    rect: Rect,
    /// Dragging state: the button that grabbed the track.
    dragging: Option<i32>,
}

impl Slider {
    pub fn new(key: &str, rect: Rect) -> Slider {
        Slider {
            key: key.to_string(),
            rect,
            dragging: None,
        }
    }

    fn bounds(&self, runtime: &ConfigRuntime) -> (f64, f64, f64) {
        match runtime.schema().entry(&self.key).map(|e| e.limits.clone()) {
            Some(Limits::Float(lo, hi, step)) => (lo, hi, step),
            Some(Limits::Int(lo, hi)) => (lo as f64, hi as f64, 1.0),
            Some(Limits::Scale(lo, hi)) => (lo as f64, hi as f64, 0.05),
            _ => (0.0, 1.0, 0.05),
        }
    }

    fn ratio(&self, runtime: &ConfigRuntime) -> f32 {
        let (lo, hi, _) = self.bounds(runtime);
        let v = runtime
            .get(&self.key)
            .and_then(ConfigValue::as_f64)
            .unwrap_or(lo);
        if hi <= lo {
            return 0.0;
        }
        clamp(((v - lo) / (hi - lo)) as f32, 0.0, 1.0)
    }

    fn set_from_pos(&self, pos: [f32; 2], runtime: &mut ConfigRuntime) -> bool {
        let (lo, hi, step) = self.bounds(runtime);
        let inner = self.rect.w - 8.0;
        let along = clamp(pos[0] - self.rect.x - 4.0, 0.0, inner) / inner.max(1.0);
        let raw = lo + along as f64 * (hi - lo);
        let snapped = if step > 0.0 {
            ((raw - lo) / step).round() * step + lo
        } else {
            raw
        };
        let value = clamp64(snapped, lo, hi);
        let typed = match runtime.get(&self.key) {
            Some(ConfigValue::Int(_)) => ConfigValue::Int(value as i64),
            Some(ConfigValue::Scale(_)) => ConfigValue::Scale(value as f32),
            _ => ConfigValue::Float(value),
        };
        runtime.set(&self.key, typed)
    }
}

/// Clamps an `f64` to `[lo, hi]` (the geometry helper is `f32`).
fn clamp64(v: f64, lo: f64, hi: f64) -> f64 {
    v.max(lo).min(hi)
}

impl Widget for Slider {
    fn key(&self) -> &str {
        &self.key
    }

    fn rect(&self) -> Rect {
        self.rect
    }

    fn draw(&self, out: &mut Vec<DrawCmd>, focused: bool, runtime: &ConfigRuntime) {
        out.push(DrawCmd::Fill {
            rect: [self.rect.x, self.rect.y, self.rect.w, self.rect.h],
            argb: if focused { PANEL_HOVER } else { PANEL },
        });
        draw_border(out, self.rect, super::BORDER);
        let ratio = self.ratio(runtime);
        let tx = self.rect.x + 4.0;
        let ty = self.rect.y + self.rect.h / 2.0 - 1.0;
        let tw = self.rect.w - 8.0;
        out.push(DrawCmd::Fill {
            rect: [tx, ty, tw, 2.0],
            argb: TRACK,
        });
        out.push(DrawCmd::Fill {
            rect: [tx, ty, tw * ratio, 2.0],
            argb: ACCENT,
        });
        out.push(DrawCmd::Fill {
            rect: [tx + tw * ratio - 2.0, ty - 4.0, 4.0, 10.0],
            argb: TEXT,
        });
        // The value, right-aligned as text.
        let value = runtime
            .get(&self.key)
            .and_then(ConfigValue::as_f64)
            .map(format_float)
            .unwrap_or_default();
        draw_label(out, &value, [tx + tw - 30.0, self.rect.y - 10.0], TEXT_DIM);
    }

    fn input(&mut self, event: &InputEvent<'_>, runtime: &mut ConfigRuntime) -> InputResult {
        match event {
            InputEvent::Press { pos, button: 0 } if self.rect.contains(*pos) => {
                self.dragging = Some(0);
                InputResult::changed_if(self.set_from_pos(*pos, runtime))
            }
            InputEvent::Drag { pos, button, .. } if self.dragging == Some(*button) => {
                InputResult::changed_if(self.set_from_pos(*pos, runtime))
            }
            InputEvent::Release { button, .. } if self.dragging == Some(*button) => {
                self.dragging = None;
                InputResult::consumed()
            }
            InputEvent::Scroll { pos, steps } if self.rect.contains(*pos) => {
                let (lo, hi, step) = self.bounds(runtime);
                let current = runtime
                    .get(&self.key)
                    .and_then(ConfigValue::as_f64)
                    .unwrap_or(lo);
                let next = clamp64(current - steps[1] as f64 * step, lo, hi);
                let typed = match runtime.get(&self.key) {
                    Some(ConfigValue::Int(_)) => ConfigValue::Int(next as i64),
                    Some(ConfigValue::Scale(_)) => ConfigValue::Scale(next as f32),
                    _ => ConfigValue::Float(next),
                };
                InputResult::changed_if(runtime.set(&self.key, typed))
            }
            _ => InputResult::ignored(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};

    const ENTRIES: &[ConfigEntry] = &[
        ConfigEntry::float("ratio", "Ratio", "help", 0.5, 0.0, 1.0, 0.05),
        ConfigEntry::int("offsetX", "X", "help", 0, -100, 100),
    ];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "general",
        label: "General",
        entries: ENTRIES,
    }];
    static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: "test_mod",
        version: 1,
        tabs: TABS,
    };

    #[test]
    fn press_sets_from_position() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut slider = Slider::new("ratio", Rect::new(10.0, 10.0, 100.0, 12.0));
        // The far right of a 0..=1 slider: 1.0, snapped to the 0.05 step.
        slider.input(
            &InputEvent::Press {
                pos: [108.0, 16.0],
                button: 0,
            },
            &mut runtime,
        );
        assert_eq!(runtime.float("ratio"), 1.0);
        // Back to the middle: 0.5.
        slider.input(
            &InputEvent::Drag {
                pos: [59.0, 16.0],
                button: 0,
                delta: [-49.0, 0.0],
            },
            &mut runtime,
        );
        assert_eq!(runtime.float("ratio"), 0.5);
    }

    #[test]
    fn integer_entries_stay_integers() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut slider = Slider::new("offsetX", Rect::new(0.0, 0.0, 100.0, 12.0));
        slider.input(
            &InputEvent::Press {
                pos: [99.0, 6.0],
                button: 0,
            },
            &mut runtime,
        );
        assert_eq!(runtime.int("offsetX"), 100);
        slider.input(
            &InputEvent::Scroll {
                pos: [50.0, 6.0],
                steps: [0.0, 2.0],
            },
            &mut runtime,
        );
        assert_eq!(runtime.int("offsetX"), 98);
    }
}
