//! The button: a momentary control that fires an action, not a setting.
//!
//! The widget model stays declarative: a button's `action` is an id the host
//! recognises (`"close"`, `"reset_tab"`, ...), because the library cannot
//! call game code.

use super::{
    ACCENT, DrawCmd, InputEvent, InputResult, PANEL, PANEL_HOVER, TEXT, Widget, draw_border,
};
use crate::config::runtime::ConfigRuntime;
use crate::utils::Rect;

pub struct Button {
    key: String,
    rect: Rect,
    label: String,
    /// The action id reported through `changed` (the key stays the button's
    /// own id; the host reads `last_action`).
    pub action: String,
    pub last_action: Option<String>,
}

impl Button {
    pub fn new(key: &str, label: &str, action: &str, rect: Rect) -> Button {
        Button {
            key: key.to_string(),
            rect,
            label: label.to_string(),
            action: action.to_string(),
            last_action: None,
        }
    }
}

impl Widget for Button {
    fn key(&self) -> &str {
        &self.key
    }

    fn rect(&self) -> Rect {
        self.rect
    }

    fn draw(&self, out: &mut Vec<DrawCmd>, focused: bool, _runtime: &ConfigRuntime) {
        out.push(DrawCmd::Fill {
            rect: [self.rect.x, self.rect.y, self.rect.w, self.rect.h],
            argb: if focused { PANEL_HOVER } else { PANEL },
        });
        draw_border(out, self.rect, if focused { ACCENT } else { super::BORDER });
        let center = self.rect.center();
        out.push(DrawCmd::Text {
            text: self.label.clone(),
            at: [0.0, center[1] - 4.0],
            rgb: TEXT,
            shadow: true,
            center_x: Some(center[0]),
        });
    }

    fn input(&mut self, event: &InputEvent<'_>, _runtime: &mut ConfigRuntime) -> InputResult {
        match event {
            InputEvent::Press { pos, button: 0 } if self.rect.contains(*pos) => {
                self.last_action = Some(self.action.clone());
                InputResult::changed()
            }
            _ => InputResult::ignored(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};

    const ENTRIES: &[ConfigEntry] = &[ConfigEntry::bool("enabled", "Enabled", "help", true)];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "general",
        label: "General",
        entries: ENTRIES,
    }];
    static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: "test_mod",
        version: 1,
        tabs: TABS,
    };

    #[test]
    fn fires_its_action_on_click() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut button = Button::new(
            "reset",
            "Reset",
            "reset_tab",
            Rect::new(0.0, 0.0, 60.0, 20.0),
        );
        assert_eq!(button.last_action, None);
        let result = button.input(
            &InputEvent::Press {
                pos: [30.0, 10.0],
                button: 0,
            },
            &mut runtime,
        );
        assert!(result.changed);
        assert_eq!(button.last_action.as_deref(), Some("reset_tab"));
        let miss = button.input(
            &InputEvent::Press {
                pos: [300.0, 10.0],
                button: 0,
            },
            &mut runtime,
        );
        assert_eq!(miss, InputResult::ignored());
    }
}
