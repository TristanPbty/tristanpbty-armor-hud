//! The toggle: a switch for a boolean entry.

use super::{ACCENT, InputEvent, InputResult, PANEL, PANEL_HOVER, TEXT, TRACK, Widget, draw_panel};
use crate::config::runtime::ConfigRuntime;
use crate::config::value::ConfigValue;
use crate::utils::Rect;

pub struct Toggle {
    key: String,
    rect: Rect,
}

impl Toggle {
    pub fn new(key: &str, rect: Rect) -> Toggle {
        Toggle {
            key: key.to_string(),
            rect,
        }
    }
}

impl Widget for Toggle {
    fn key(&self) -> &str {
        &self.key
    }

    fn rect(&self) -> Rect {
        self.rect
    }

    fn draw(&self, out: &mut Vec<super::DrawCmd>, focused: bool, runtime: &ConfigRuntime) {
        let on = runtime.bool(&self.key);
        draw_panel(
            out,
            self.rect,
            if focused { PANEL_HOVER } else { PANEL },
            super::BORDER,
        );
        // A 26x13 track with an 11x11 knob, like vanilla's cycling buttons
        // read at a glance.
        let track_w = 26.0;
        let track_h = 13.0;
        let tx = self.rect.right() - track_w - 6.0;
        let ty = self.rect.y + (self.rect.h - track_h) / 2.0;
        out.push(super::DrawCmd::Fill {
            rect: [tx, ty, track_w, track_h],
            argb: TRACK,
        });
        let knob_x = if on { tx + track_w - 12.0 } else { tx + 1.0 };
        out.push(super::DrawCmd::Fill {
            rect: [knob_x, ty + 1.0, 11.0, 11.0],
            argb: if on { ACCENT } else { TEXT },
        });
        out.push(super::DrawCmd::Text {
            text: if on { "On" } else { "Off" }.to_string(),
            at: [tx - 18.0, self.rect.y + self.rect.h / 2.0 - 4.0],
            rgb: TEXT,
            shadow: true,
            center_x: None,
        });
    }

    fn input(&mut self, event: &InputEvent<'_>, runtime: &mut ConfigRuntime) -> InputResult {
        match event {
            InputEvent::Press { pos, button: 0 } if self.rect.contains(*pos) => {
                let next = !runtime.bool(&self.key);
                runtime.set(&self.key, ConfigValue::Bool(next));
                InputResult::changed()
            }
            _ => InputResult::ignored(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};

    const ENTRIES: &[ConfigEntry] = &[ConfigEntry::bool("enabled", "Enabled", "help", true)];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "general",
        label: "General",
        entries: ENTRIES,
    }];
    static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: "test_mod",
        version: 1,
        tabs: TABS,
    };

    #[test]
    fn clicking_toggles_the_entry() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut toggle = Toggle::new("enabled", Rect::new(0.0, 0.0, 100.0, 20.0));
        assert!(runtime.bool("enabled"));
        let press = InputEvent::Press {
            pos: [50.0, 10.0],
            button: 0,
        };
        assert!(toggle.input(&press, &mut runtime).changed);
        assert!(!runtime.bool("enabled"));
        assert!(toggle.input(&press, &mut runtime).changed);
        assert!(runtime.bool("enabled"));
        // Outside the rect: ignored.
        let miss = InputEvent::Press {
            pos: [500.0, 10.0],
            button: 0,
        };
        assert_eq!(toggle.input(&miss, &mut runtime), InputResult::ignored());
        // Right button: ignored.
        let right = InputEvent::Press {
            pos: [50.0, 10.0],
            button: 1,
        };
        assert_eq!(toggle.input(&right, &mut runtime), InputResult::ignored());
    }

    #[test]
    fn draws_a_track_and_knob() {
        let runtime = ConfigRuntime::in_memory(&SCHEMA);
        let toggle = Toggle::new("enabled", Rect::new(0.0, 0.0, 100.0, 20.0));
        let mut out = Vec::new();
        toggle.draw(&mut out, false, &runtime);
        assert!(out.len() >= 6);
    }
}
