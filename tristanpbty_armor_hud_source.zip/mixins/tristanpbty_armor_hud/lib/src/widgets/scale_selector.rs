//! The scale selector: preset buttons plus a fine slider for a scale entry.

use super::{
    ACCENT, DrawCmd, InputEvent, InputResult, PANEL, PANEL_HOVER, TEXT, TEXT_DIM, Widget,
    draw_border, draw_label, slider::Slider,
};
use crate::config::runtime::ConfigRuntime;
use crate::config::value::{ConfigValue, format_float};
use crate::utils::Rect;

/// The presets a click snaps to.
pub const PRESETS: [f32; 5] = [0.5, 0.75, 1.0, 1.5, 2.0];

pub struct ScaleSelector {
    key: String,
    rect: Rect,
    fine: Option<Slider>,
}

impl ScaleSelector {
    pub fn new(key: &str, rect: Rect) -> ScaleSelector {
        ScaleSelector {
            key: key.to_string(),
            rect,
            fine: None,
        }
    }

    fn preset_rect(&self, index: usize) -> Rect {
        let per = self.rect.w / PRESETS.len() as f32;
        Rect::new(
            self.rect.x + index as f32 * per + 1.0,
            self.rect.y + 1.0,
            per - 2.0,
            self.rect.h - 2.0,
        )
    }

    fn slider_rect(&self) -> Rect {
        Rect::new(self.rect.x, self.rect.bottom() + 2.0, self.rect.w, 12.0)
    }
}

impl Widget for ScaleSelector {
    fn key(&self) -> &str {
        &self.key
    }

    fn rect(&self) -> Rect {
        self.rect
    }

    fn draw(&self, out: &mut Vec<DrawCmd>, focused: bool, runtime: &ConfigRuntime) {
        let current = runtime.scale(&self.key);
        out.push(DrawCmd::Fill {
            rect: [self.rect.x, self.rect.y, self.rect.w, self.rect.h],
            argb: if focused { PANEL_HOVER } else { PANEL },
        });
        draw_border(out, self.rect, super::BORDER);
        for (i, preset) in PRESETS.iter().enumerate() {
            let rect = self.preset_rect(i);
            let active = (current - preset).abs() < 1e-3;
            out.push(DrawCmd::Fill {
                rect: [rect.x, rect.y, rect.w, rect.h],
                argb: if active { ACCENT } else { 0xFF1A_1A1A },
            });
            draw_border(out, rect, super::BORDER);
            let center = rect.center();
            out.push(DrawCmd::Text {
                text: format!("{}x", format_float(*preset as f64)),
                at: [0.0, center[1] - 4.0],
                rgb: TEXT,
                shadow: false,
                center_x: Some(center[0]),
            });
        }
        if let Some(slider) = &self.fine {
            slider.draw(out, focused, runtime);
        } else {
            draw_label(
                out,
                &format!("scale {}x", format_float(current as f64)),
                [self.rect.x, self.rect.bottom() + 3.0],
                TEXT_DIM,
            );
        }
    }

    fn input(&mut self, event: &InputEvent<'_>, runtime: &mut ConfigRuntime) -> InputResult {
        // The fine slider, once opened, takes events first.
        if let Some(slider) = self.fine.as_mut() {
            let result = slider.input(event, runtime);
            if result.consumed {
                return result;
            }
        }
        match event {
            InputEvent::Press { pos, button: 0 } if self.rect.contains(*pos) => {
                for (i, preset) in PRESETS.iter().enumerate() {
                    if self.preset_rect(i).contains(*pos) {
                        return InputResult::changed_if(
                            runtime.set(&self.key, ConfigValue::Scale(*preset)),
                        );
                    }
                }
                // A press on the row but outside a preset opens the fine
                // slider (or turns it off when already there).
                if self.fine.is_some() {
                    self.fine = None;
                } else {
                    self.fine = Some(Slider::new(&self.key, self.slider_rect()));
                }
                InputResult::consumed()
            }
            _ => InputResult::ignored(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};

    const ENTRIES: &[ConfigEntry] = &[ConfigEntry::scale("scale", "Scale", "help", 1.0, 0.5, 2.0)];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "display",
        label: "Display",
        entries: ENTRIES,
    }];
    static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: "test_mod",
        version: 1,
        tabs: TABS,
    };

    #[test]
    fn presets_snap_on_click() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut selector = ScaleSelector::new("scale", Rect::new(0.0, 0.0, 100.0, 16.0));
        // The last preset is at the right end: 2.0x.
        selector.input(
            &InputEvent::Press {
                pos: [98.0, 8.0],
                button: 0,
            },
            &mut runtime,
        );
        assert_eq!(runtime.scale("scale"), 2.0);
        // The first preset: 0.5x.
        selector.input(
            &InputEvent::Press {
                pos: [2.0, 8.0],
                button: 0,
            },
            &mut runtime,
        );
        assert_eq!(runtime.scale("scale"), 0.5);
    }

    #[test]
    fn fine_slider_opens_and_moves() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut selector = ScaleSelector::new("scale", Rect::new(0.0, 0.0, 100.0, 16.0));
        // Open the fine slider with a press between two presets.
        selector.input(
            &InputEvent::Press {
                pos: [20.0, 8.0],
                button: 0,
            },
            &mut runtime,
        );
        assert!(selector.fine.is_some());
        // Drag the slider: the scale entry is a Scale value, so the slider
        // writes Scale back.
        selector.input(
            &InputEvent::Press {
                pos: [90.0, 26.0],
                button: 0,
            },
            &mut runtime,
        );
        assert!(runtime.scale("scale") > 1.4);
    }
}
