// The configuration screen, drawn over the mod's own screen. The game draws
// the screen's blurred background; everything on it is the mod's.
fn screen_draw(
    game: &crate::game::Game<'_>,
    batch: &mut HudBatch,
    screen: &NativeScreenView<'_>,
) {
    if screen.id != "mod" {
        return;
    }
    if game.native_mod_screen() != Some("tristanpbty_armor_hud") {
        return;
    }
    let cursor = game.native_cursor();
    let draws = crate::game::tristanpbty_armor_hud::screen_draw(
        [batch.width, batch.height],
        cursor,
    );
    for draw in &draws {
        match draw {
            crate::game::tristanpbty_armor_hud::DrawCmd::Fill { rect, argb } => {
                game.native_fill(batch, *rect, *argb);
            }
            crate::game::tristanpbty_armor_hud::DrawCmd::Sprite { name, src, dst, .. } => {
                game.native_sprite(batch, name, *src, *dst);
            }
            crate::game::tristanpbty_armor_hud::DrawCmd::Text {
                text,
                at,
                rgb,
                shadow,
                center_x,
            } => {
                let x = match center_x {
                    Some(cx) => cx - game.native_text_width(text) / 2.0,
                    None => at[0],
                };
                game.native_text(batch, text, [x, at[1]], *rgb, *shadow);
            }
            // The screen's only item is its header emblem: the vanilla
            // turtle helmet (MOD_LOGO_ITEM), drawn like the HUD's armor
            // items. The snapshot index is meaningless here — the screen
            // owns no stacks — so whatever it names draws the emblem.
            crate::game::tristanpbty_armor_hud::DrawCmd::Item { at, size, .. } => {
                let emblem = ItemStack::new(crate::game::tristanpbty_armor_hud::MOD_LOGO_ITEM, 1);
                game.native_item_stack(batch, &emblem, *at, *size);
            }
        }
    }
}
