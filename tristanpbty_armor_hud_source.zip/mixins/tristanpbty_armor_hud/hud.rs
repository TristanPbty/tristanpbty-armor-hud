// The HUD draw: collects the player's equipment, computes the layout and
// interprets its draw list through Horizon's GUI helpers. Runs once per HUD
// frame, before the trait mods' dispatch in the same hook point.
fn hud(
    game: &mut crate::game::Game<'_>,
    batch: &mut HudBatch,
    corners: &mut Corners,
) {
    use crate::game::tristanpbty_armor_hud as armor_hud;

    // A mod turned off in Options > Mods does nothing until the launcher's
    // next build leaves it out — the hook contract says to check this first.
    if !game.native_on(armor_hud::MOD_ID) {
        return;
    }

    // Attach the configuration file once the game folder is known.
    if let Ok(dir) = crate::game::native_hooks::Game::native_config_dir() {
        armor_hud::init_storage(dir);
    }

    // The player's equipment as plain values, with the item registry's own
    // durability math (an unbreakable stack has none; a `minecraft:max_damage`
    // component overrides the item's own) and its own foil check: an
    // enchantment-glint override component, the item's own glint, or a
    // non-empty enchantments component — the same inputs `native_item_stack`
    // will look at when it resolves the stack we rebuild below.
    let max_of = |stack: &ItemStack| {
        let items = game.res.items();
        let item_max = items.get(&*stack.item).map_or(0, |i| i.max_damage);
        let unbreakable = stack
            .data()
            .is_some_and(|d| d.other("minecraft:unbreakable").is_some());
        if item_max == 0 || unbreakable {
            0
        } else {
            horizon_client::item_render::cit::stack_max_damage(stack, item_max)
        }
    };
    let glint_of = |stack: &ItemStack| {
        let item_glint = game
            .res
            .items()
            .enchantments
            .props
            .get(&*stack.item)
            .is_some_and(|p| p.glint);
        stack.has_foil(item_glint)
    };
    let info = |stack: &Option<ItemStack>| {
        stack.as_ref().map(|s| armor_hud::StackInfo {
            item: s.item.to_string(),
            count: s.count,
            damage: s.damage,
            max_damage: max_of(s),
            glint: glint_of(s),
        })
    };
    let armor = [
        info(&game.armor[0]),
        info(&game.armor[1]),
        info(&game.armor[2]),
        info(&game.armor[3]),
    ];
    let offhand = info(&game.offhand);
    let main_hand = game
        .inventory
        .get(game.selected)
        .and_then(|slot| slot.as_ref())
        .map(|s| armor_hud::StackInfo {
            item: s.item.to_string(),
            count: s.count,
            damage: s.damage,
            max_damage: max_of(s),
            glint: glint_of(s),
        });
    let now_ms = armor_hud::state().lock().unwrap().now_ms;
    let snapshot = armor_hud::EquipmentSnapshot {
        armor,
        offhand,
        main_hand,
        selected: game.selected,
        right_handed: !game.settings.main_hand_left,
        attack_indicator_hotbar: game.settings.attack_indicator == 2,
        attack_charging: game.attack_strength_scale() < 1.0,
        screen: [batch.width, batch.height],
        now_ms,
    };

    let settings = {
        let state = armor_hud::state().lock().unwrap();
        armor_hud::settings_of(&state.runtime)
    };
    let mut layout = armor_hud::hud_layout(&settings, &snapshot);
    if layout.draws.is_empty() && layout.hotbar_extras.is_empty() {
        return;
    }

    // The status effect rows: stack below them when the settings ask for it.
    if let Some((_, side)) = layout.reserve_corner {
        let corner = if side == armor_hud::Side::Right {
            Corner::TopRight
        } else {
            Corner::TopLeft
        };
        // The debug screen owns the top left corner, as it does the
        // minimap's.
        if corner == Corner::TopLeft && game.debug {
            return;
        }
        let (x, y) = corners.place(corner, layout.rect.w, layout.rect.h);
        let by = [x - layout.rect.x, y - layout.rect.y];
        armor_hud::translate_draws(&mut layout.draws, by);
        layout.rect = armor_hud::Rect::new(x, y, layout.rect.w, layout.rect.h);
    }

    // Interpret the draw list.
    {
        let mut paint = |draws: &[armor_hud::DrawCmd]| {
            for draw in draws {
                match draw {
                    armor_hud::DrawCmd::Fill { rect, argb } => {
                        game.native_fill(batch, *rect, *argb);
                    }
                    armor_hud::DrawCmd::Sprite { name, src, dst, .. } => {
                        game.native_sprite(batch, name, *src, *dst);
                    }
                    armor_hud::DrawCmd::Text {
                        text,
                        at,
                        rgb,
                        shadow,
                        center_x,
                    } => {
                        let x = match center_x {
                            Some(cx) => cx - game.native_text_width(text) / 2.0,
                            None => at[0],
                        };
                        game.native_text(batch, text, [x, at[1]], *rgb, *shadow);
                    }
                    armor_hud::DrawCmd::Item { stack, at, size } => {
                        if let Some(info) = layout.stacks.get(*stack) {
                            let mut owned = ItemStack {
                                item: info.item.clone().into(),
                                count: info.count.max(1),
                                damage: info.damage,
                                extra: None,
                            };
                            // The snapshot's stacks are plain values, so the
                            // enchantments stayed behind. The vanilla glint only
                            // asks whether the list is non-empty, and the HUD
                            // shows no enchantment names, so a stand-in restores
                            // the shimmer. (An OptiFine CIT rule that matches
                            // `unbreaking` on GUI items could theoretically
                            // restyle the icon — a pack that does that also
                            // restyles genuinely enchanted armor, so it reads
                            // as intended.)
                            if info.glint {
                                owned.enchant("minecraft:unbreaking", 1);
                            }
                            game.native_item_stack(batch, &owned, *at, *size);
                        }
                    }
                }
            }
        };
        paint(&layout.draws);
        paint(&layout.hotbar_extras);
    }

    // The low-durability sound: vanilla's own item-break event, played once
    // per warning that newly appears (the state's cooldown holds the rest),
    // where the player stands.
    if armor_hud::notice_warnings(&layout.warnings, settings.warning_sound)
        && let Some(player) = game.player.as_ref()
    {
        let at = [player.position.x, player.position.y, player.position.z];
        game.native_play_local_sound(
            armor_hud::BREAK_SOUND,
            at,
            armor_hud::BREAK_SOUND_VOLUME,
            armor_hud::BREAK_SOUND_PITCH,
            0,
        );
    }
}
