// The menu key: opens the configuration screen, or closes it when it is
// already open. The binding itself lives in the game's own mod-key storage
// (`horizon-mods.txt`), read here per event.
fn keybind(game: &mut crate::game::Game<'_>, key: &str, pressed: bool) {
    use crate::game::tristanpbty_armor_hud::{
        close_screen, open_screen, state, Action, DEFAULT_MENU_KEY, MENU_KEY_NAME, MOD_ID,
    };
    // A mod turned off in Options > Mods does nothing until the launcher's
    // next build leaves it out.
    if !game.native_on(MOD_ID) {
        return;
    }
    let bound = game.native_mod_key(MOD_ID, MENU_KEY_NAME, DEFAULT_MENU_KEY);
    {
        let mut state = state().lock().unwrap();
        state.menu_key = bound;
    }
    if crate::game::tristanpbty_armor_hud::key(key, pressed) == Action::ToggleScreen {
        let open = game.native_mod_screen().is_some_and(|id| id == MOD_ID);
        if open {
            close_screen();
            game.native_mod_screen_close(MOD_ID);
        } else if game.native_mod_screen_open(MOD_ID) {
            open_screen();
        }
    }
}
