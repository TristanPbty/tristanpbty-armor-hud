// A click on one of the mod's Options > Mods buttons: the reset button.
fn settings_click(mod_id: &str, button: usize) {
    use crate::game::tristanpbty_armor_hud::{reset_settings, MOD_ID};
    if mod_id != MOD_ID {
        return;
    }
    if button == 0 {
        reset_settings();
    }
}
