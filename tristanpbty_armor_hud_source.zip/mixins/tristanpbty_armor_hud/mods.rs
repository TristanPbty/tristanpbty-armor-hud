// The mod manager's list (Options > Mods): the row the game builds from what
// the `mods` hook pushes — the id, the `Name 1.0` title, the description and
// the menu key. The key's name must match the one `keybind.rs` reads back, so
// the player's rebinding (`key.tristanpbty_armor_hud.menu` in
// `horizon-mods.txt`) is the same line both ways. The helper is `list_mods`,
// not `mods`: a helper may not shadow the target's parameter names.
//
// No macros in here — `format!`, `vec!` and friends would land inside
// `native_hooks.rs`, whose own test (`hook_points_stay_hookable`) keeps the
// hook points free of them so horizon-mixins can keep parsing the file.
fn list_mods(mods: &mut Vec<NativeMod>) {
    use crate::game::tristanpbty_armor_hud::{
        DEFAULT_MENU_KEY, MENU_KEY_LABEL, MENU_KEY_NAME, MOD_DESCRIPTION, MOD_ID, MOD_NAME,
        MOD_VERSION,
    };
    let menu_key = [
        String::from(MENU_KEY_NAME),
        String::from(MENU_KEY_LABEL),
        String::from(DEFAULT_MENU_KEY),
    ];
    let mut keys = Vec::new();
    keys.push(menu_key);
    mods.push(NativeMod {
        id: String::from(MOD_ID),
        title: [MOD_NAME, " ", MOD_VERSION].concat(),
        description: String::from(MOD_DESCRIPTION),
        keys,
    });
}
