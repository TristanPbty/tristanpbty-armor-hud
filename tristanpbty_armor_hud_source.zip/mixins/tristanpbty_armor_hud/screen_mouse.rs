// A mouse press on the configuration screen: the widgets take it, and the
// screen's own handling is cancelled when they do.
fn screen_mouse(
    game: &crate::game::Game<'_>,
    screen: &NativeScreenView<'_>,
    button: i32,
    canceled: &mut bool,
) {
    if screen.id != "mod" || game.native_mod_screen() != Some("tristanpbty_armor_hud") {
        return;
    }
    let pos = game.native_cursor();
    let event = tristanpbty_armor_hud_lib::widgets::InputEvent::Press { pos, button };
    if crate::game::tristanpbty_armor_hud::screen_input(&event) {
        *canceled = true;
    }
}
