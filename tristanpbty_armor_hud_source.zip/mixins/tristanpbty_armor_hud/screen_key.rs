// A key press on the configuration screen: the number fields type, the
// keybind capture listens, Tab changes pages.
fn screen_key(
    game: &crate::game::Game<'_>,
    screen: &NativeScreenView<'_>,
    key: &str,
    canceled: &mut bool,
) {
    if screen.id != "mod" || game.native_mod_screen() != Some("tristanpbty_armor_hud") {
        return;
    }
    let event = tristanpbty_armor_hud_lib::widgets::InputEvent::Key {
        name: key,
        text: None,
    };
    if crate::game::tristanpbty_armor_hud::screen_input(&event) {
        *canceled = true;
    }
}
