# TristanPbty's Armor Hud (`tristanpbty_armor_hud`)

A faithful, native reimplementation of the minimal armor HUD widget known
from **Uku's Armor HUD** (itself a fork of BerdinskiyBear's mod), for
[Horizon](https://github.com/horizon-rust/horizon), the Minecraft Java
Edition client in Rust. No Java, no JVM, no Fabric/Forge/Quilt jar: this is
a **source mixin bundle** (horizon-mixins) that the Horizon launcher
compiles into the game, shipped as the source-only
`tristanpbty_armor_hud-1.1.0.hnmod`.

**The mod is self-contained**: the library it uses (Tristan's Lib) is
bundled inside its own `.hnmod` as its own crate
(`tristanpbty_armor_hud_lib`), staged into the game build by the bundle's
`[[crate]]` — so it installs, builds and runs **alone**. The standalone
library mod (`tristanpbty_lib`) can sit beside it; the two crates carry
different names, and both mods were staged together against the pinned
Horizon sources without conflict.

The widget shows the equipped armor as item slots beside or around the HUD,
with vanilla-style slot backgrounds, the enchantment glint, per-item
durability, and a bobbing low-durability warning — the reference's own
`warn.png` mark, pixel for pixel — plus the vanilla item-break sound when a
warning appears. Everything is positioned by anchor, side, offsets and
scale, configured in an in-game screen of plain vanilla-style buttons (the
menu key **H** is rebindable in Options > Mods). The mod lists itself in
the game's mod manager with its name, version, description and a reset
button.

## Layout

```
Cargo.toml               the standalone workspace: builds and tests the
                         runtime against the exact vendored library copy
rust-toolchain.toml      Rust 1.95.0 (the pinned toolchain)
compatibility.json       the exact Horizon / horizon-mixins pins
mixins/tristanpbty_armor_hud/
    horizon-mixin.toml   the bundle manifest: 1 [[crate]], 1 [[module]],
                         11 named-hook injections
    runtime.rs           all logic, injected as the game module
                         crate::game::tristanpbty_armor_hud and built
                         standalone with its 17 tests
    hud.rs … settings_click.rs   thin typed hook helpers (game glue)
    lib/                 Tristan's Lib vendored as its own crate
                         (tristanpbty_armor_hud_lib; sources byte-identical
                         to the library's, only the crate's Cargo.toml
                         differs — tools/sync_bundle.py regenerates it)
tools/                   package.py, sync_bundle.py, stage.sh
```

## Build, test, package

```sh
cargo fmt --all --check
cargo clippy --workspace --all-targets --locked -- -D warnings
cargo test --workspace --locked      # 17 mod tests + 69 vendored-lib tests
python3 tools/package.py             # → target/tristanpbty_armor_hud-1.1.0.hnmod
```

The packager writes `horizon-native.json` plus every `.rs`/`.toml` of the
bundle and `LICENSES.md`, with fixed timestamps and modes, so the same
sources always give the same bytes and the same SHA-256. The vendored
library copy is committed in the bundle — nothing beside this checkout is
needed to rebuild the `.hnmod` exactly.

To verify against the real game sources (needs the two pinned checkouts
beside this one):

```sh
HORIZON=../horizon HORIZON_MIXINS=../horizon-mixins tools/stage.sh
WITH_LIB=1 …   # also stage the standalone library mod beside it
```

`stage.sh` runs the real horizon-mixins CLI (`plan`, `apply`, `check`)
over this mod's bundle — alone by default, which is how it installs.

## Pins (compatibility.json)

| What | Pin |
|---|---|
| Horizon | Nightly **2026-11-08**, commit `fdc87aecdbd116bf1e08adcd062fcbaea8c2e2ca` (`NATIVE_HOOKS_API` 411) |
| horizon-mixins | `d9c83d7096b7ea5b83678da2efdfd6161f74997e` (0.6.0, plan schema 6) |
| game.rs @ pin | `419c2bdd785f2fef499ae460c41f0bfc125b19fb12a8a8c3cef54b27de4687df` (carries the injected module) |
| native_hooks.rs @ pin | `2cb9c8f04dd92484ae22788c61d658a76b34ab74bf9deab06b0e44958eecd5bd` (carries the 11 helper injections) |
| Rust | 1.95.0 (`rust-toolchain.toml`) |

Both staging scenarios were executed for this build against the pinned
sources — this mod alone, and together with the standalone library mod:
`plan` and `apply` clean, `cargo check -p horizon-client
--no-default-features` with 0 warnings, and the game's own test suite
(1127 passed, 0 failed, 137 ignored — upstream ignores) including the 17
injected-module tests and `hook_points_stay_hookable`.

## Install

Put `tristanpbty_armor_hud-1.1.0.hnmod` in the game folder's
`horizon-native-mods/` (or install it from the registry through the
launcher's Mods page). The launcher shows its trust notice (native mods run
with your user rights; that is Horizon's model) and compiles it on the
pinned Nightly. In game: press **H** for the configuration screen;
`config/tristanpbty_armor_hud.json` is also editable by hand.

## What is *not* implemented, and why (no fakes)

- `pushBossbars` / `pushSubtitles` are accepted, stored and shown in the
  config, but do not yet displace those overlays: Horizon computes those
  layouts in free functions with no exposed offset. It needs an upstream
  hook; the mod records the push it *would* apply.
- A custom sound file cannot ship (the `.hnmod` format is sources only):
  the warning sound is the vanilla item-break event itself.
- Bobbing is a fixed sine cycle (deterministic, testable), not the
  reference's random jitter.
- The glint is restored through a stand-in enchantment
  (`minecraft:unbreaking`).
- The vanilla armor-points row is left alone (as the reference does).

## Licenses

MIT, by TristanPbty — see `LICENSES.md` (which also travels inside the
`.hnmod`) for the full attributions: horizon-native-mod-template (MIT) for
the packaging and staging approach; uku3lig/armor-hud (MIT, itself from
BerdinskiyBear's mod) for the behavior, geometry and configuration
vocabulary, reimplemented from scratch in Rust — the warning mark is that
mod's `warn.png` reproduced pixel for pixel as fills. No Horizon source, no
Minecraft assets.

## Changelog

- **1.1.0** — the mod is now self-contained: the library is bundled inside
  its own `.hnmod` as its own crate (`tristanpbty_armor_hud_lib`), so it
  builds and runs alone (the standalone library mod is optional and
  coexists without conflict). The configuration screen was rebuilt around
  plain vanilla-style cycling buttons (`Armor HUD: On`, `Slot style:
  Hotbar` — click or scroll to step) with tabs and a Done button; the
  custom toggles, dropdowns, number fields, sliders, scale selectors and
  the live preview are gone (the preview overlapped the controls, which
  made the screen misbehave). New **Text color** setting (Auto —
  vanilla's damage scale — or one of ten fixed colors). A screen closed
  with Escape now saves too.
- **1.0.0** — the enchantment glint; the mod manager listing (name,
  version, description, rebindable menu key, reset button); `native_on`
  gating; macro-free helpers; pinned to the newest Nightly (2026-11-08);
  the warning mark as the reference's `warn.png` dome, pixel for pixel; the
  warning sound (vanilla item-break event, own switch, on by default).
- **0.1.1** — fixed slot backgrounds not drawing (full HUD atlas keys).
- **0.1.0** — initial release.
